# abis_common

- [abis_common](#abis_common)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [ABIS_MATCHING_CONFIG_ROOT](#abis_matching_config_root)
    - [ABIS_COMMON_PACKAGES](#abis_common_packages)
    - [ABIS_COMMON_FLAVOUR](#abis_common_flavour)
    - [DERMALOG_ABIS_VERSIONS_ABIS_SYSTEMCHECK](#dermalog_abis_versions_abis_systemcheck)
    - [DERMALOG_ABIS_VERSIONS_DERMALOG_CFG](#dermalog_abis_versions_dermalog_cfg)
    - [DERMALOG_ABIS_VERSIONS_SOSPLUGIN](#dermalog_abis_versions_sosplugin)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role provides utilities for ABIS Matching configuration settings and installs common packages.

## Requirements

none

## Role Variables

### ABIS_MATCHING_CONFIG_ROOT

Defines the target directory of the ABIS Matching configuration files.

Default:

    ABIS_MATCHING_CONFIG_ROOT: '/etc/opt/dermalog/abismatching/'

### ABIS_COMMON_PACKAGES

Defines common packages to be installed on all ABIS Backend nodes.

Default:

    ABIS_COMMON_PACKAGES:
    - "dermalog-abis-systemcheck-{{ DERMALOG_ABIS_VERSIONS_ABIS_SYSTEMCHECK }}"
    - "dermalog-cfg-{{ DERMALOG_ABIS_VERSIONS_DERMALOG_CFG }}"
    - "dermalog-sosplugin-{{ DERMALOG_ABIS_VERSIONS_SOSPLUGIN }}"

### ABIS_COMMON_FLAVOUR

Defines the set of ABIS Matching configurations to used for matching requests.

Available flavours are:

* `DEMO`
* `CRIMINAL`
* `FACEVIDEOID`
* `WEBABIS_CIVIL`

For overiding thresholds or writing your own flavour of ABIS Matching configurations please have a look at the provided defaults.

Default: undefined

### DERMALOG_ABIS_VERSIONS_ABIS_SYSTEMCHECK

Defines the version of the package dermalog-abis-systemcheck to be installed.

Default: undefined

### DERMALOG_ABIS_VERSIONS_DERMALOG_CFG

Defines the version of the package dermalog-cfg to be installed.

Default: undefined

### DERMALOG_ABIS_VERSIONS_SOSPLUGIN

Defines the version of the package dermalog-sosplugin to be installed.

Default: undefined

## Dependencies

none

## Example Playbook

Include the role in your playbook(s).

    - hosts: all
      roles:
        - role: abis_common

Configure the ABIS Matching configuration flavour in your inventory data.
Use any of the predefined flavours or reference your selfdefined one.

    ABIS_COMMON_FLAVOUR: 'DEMO'

## License

proprietary
