# abis_repo

This role configures the package repository to be used for installing all ABIS Backend packages.

## Requirements

none

## Role Variables

### ABIS_REPOSITORIES

Defines the package repositories that shall be configured in order to install ABIS Backend and the required dependencies.

For each repository there are required these attributes:

* `NAME` defines the short name of the repository.
* `DESCRIPTION` defines the description of the repository.
* `REPO_BASEURL` defines the base URL of the repository.

Example

    ABIS_REPOSITORIES:
      - NAME: 'dermalog-abis'
        DESCRIPTION: 'ABIS yum repo 16.2.0'
        REPO_BASEURL: 'https://nexusrepo.dc.dermalog.com/repository/yum-products/ABISBackend/16.2.0/el8/'

Default:

    ABIS_REPOSITORIES: []

## Dependencies

none

## Example Playbook

Include the role in your playbook(s).

    - hosts: all
      roles:
        - role: abis_repo

Configure the list of repositories that are required for the ABIS Backend installation.

    ABIS_REPOSITORIES:
      - NAME: 'dermalog-abis'
        DESCRIPTION: "ABIS yum repo {{ ABIS_VERSION }}"
        REPO_BASEURL: "{{ ABIS_REPO_BASEURL }}/{{ ABIS_VERSION }}/{{ OS_PLATFORM }}/"
        SSLVERIFY: false
    ABIS_VERSION: '15.1.0'
    OS_PLATFORM: 'el7'
    ABIS_REPO_BASEURL: 'https://nexusrepo.dc.dermalog.com/repository/yum-products/ABISBackend'

If the repository configuration shall not be managed by this role then stick with the default of parameter *ABIS_REPOSITORIES*:

    ABIS_REPOSITORIES: []

## License

proprietary
