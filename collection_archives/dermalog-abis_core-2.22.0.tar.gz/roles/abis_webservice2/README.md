# abis_webservice2

- [abis_webservice2](#abis_webservice2)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [ABIS_FUSIONS](#abis_fusions)
    - [ABIS_WEBSERVICE2_PACKAGES](#abis_webservice2_packages)
    - [ABIS_WEBSERVICE2_JAVA_HOME](#abis_webservice2_java_home)
    - [ABIS_WEBSERVICE2_SERVICE_PORT](#abis_webservice2_service_port)
    - [ABIS_WEBSERVICE2_CONTEXT_PATH](#abis_webservice2_context_path)
    - [ABIS_WEBSERVICE2_SERVICE_MAX_THREADS](#abis_webservice2_service_max_threads)
    - [ABIS_WEBSERVICE2_CORS_ALLOWED_ORIGINS](#abis_webservice2_cors_allowed_origins)
    - [ABIS_WEBSERVICE2_ABIS_READ_TARGET](#abis_webservice2_abis_read_target)
    - [ABIS_WEBSERVICE2_ABIS_READ_TIMEOUT](#abis_webservice2_abis_read_timeout)
    - [ABIS_WEBSERVICE2_ABIS_READ_ENCRYPTION_CLIENT_KEYS_PATH](#abis_webservice2_abis_read_encryption_client_keys_path)
    - [ABIS_WEBSERVICE2_ABIS_READ_ENCRYPTION_SERVER_KEYS_PATH](#abis_webservice2_abis_read_encryption_server_keys_path)
    - [ABIS_WEBSERVICE2_ASYNC_PERSISTENCE_FILE_BASEPATH](#abis_webservice2_async_persistence_file_basepath)
    - [ABIS_WEBSERVICE2_ABIS_BIOMETRIC_TARGET](#abis_webservice2_abis_biometric_target)
    - [ABIS_WEBSERVICE2_ABIS_BIOMETRIC_TIMEOUT](#abis_webservice2_abis_biometric_timeout)
    - [ABIS_WEBSERVICE2_ABIS_BIOMETRIC_ENCRYPTION_CLIENT_KEYS_PATH](#abis_webservice2_abis_biometric_encryption_client_keys_path)
    - [ABIS_WEBSERVICE2_ABIS_BIOMETRIC_ENCRYPTION_SERVER_KEYS_PATH](#abis_webservice2_abis_biometric_encryption_server_keys_path)
    - [ABIS_WEBSERVICE2_ABIS_SPECIFIC_ACTION_TIMEOUTS](#abis_webservice2_abis_specific_action_timeouts)
    - [ABIS_WEBSERVICE2_SEARCH_THRESHOLD](#abis_webservice2_search_threshold)
    - [ABIS_WEBSERVICE2_VERIFY_THRESHOLD](#abis_webservice2_verify_threshold)
    - [ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_USE_SHAPE_CODING](#abis_webservice2_encoding_fingerprint_use_shape_coding)
    - [ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_USE_PATCH_DESCRIPTOR](#abis_webservice2_encoding_fingerprint_use_patch_descriptor)
    - [ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_CORE_DELTA_DETECTION](#abis_webservice2_encoding_fingerprint_core_delta_detection)
    - [ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_USE_MINUTIAE_FILTER](#abis_webservice2_encoding_fingerprint_use_minutiae_filter)
    - [ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_MINUTIAE_FILTER_THRESHOLD](#abis_webservice2_encoding_fingerprint_minutiae_filter_threshold)
    - [ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_MINUTIAE_FILTER_MIN_MINUTIA](#abis_webservice2_encoding_fingerprint_minutiae_filter_min_minutia)
    - [ABIS_WEBSERVICE2_ENCODING_FACE_ENCODING_TYPE](#abis_webservice2_encoding_face_encoding_type)
    - [ABIS_WEBSERVICE2_ENCODING_FACE_PLATFORM](#abis_webservice2_encoding_face_platform)
    - [ABIS_WEBSERVICE2_LIVELINESS_FACE_THRESHOLD](#abis_webservice2_liveliness_face_threshold)
    - [ABIS_WEBSERVICE2_TEMPLATE_VERIFICATION_WORKERS](#abis_webservice2_template_verification_workers)
    - [ABIS_WEBSERVICE2_LOCAL_PARALLEL_WORKERS](#abis_webservice2_local_parallel_workers)
    - [ABIS_WEBSERVICE2_TARGET_SEARCH_MAX_ITEMS](#abis_webservice2_target_search_max_items)
    - [ABIS_WEBSERVICE2_TARGET_SEARCH_THREADS](#abis_webservice2_target_search_threads)
    - [ABIS_WEBSERVICE2_FALLBACK_VERIFICATION_ENABLED](#abis_webservice2_fallback_verification_enabled)
    - [ABIS_WEBSERVICE2_FALLBACK_VERIFICATION_DURATION](#abis_webservice2_fallback_verification_duration)
    - [ABIS_WEBSERVICE2_GROUPS](#abis_webservice2_groups)
    - [ABIS_WEBSERVICE2_MODE_FACE_ENCODE](#abis_webservice2_mode_face_encode)
    - [ABIS_WEBSERVICE2_MODE_FACE_FEATURE](#abis_webservice2_mode_face_feature)
    - [ABIS_WEBSERVICE2_MODE_FACE_LIVELINESS](#abis_webservice2_mode_face_liveliness)
    - [ABIS_WEBSERVICE2_MODE_FACE_ICAO](#abis_webservice2_mode_face_icao)
    - [ABIS_WEBSERVICE2_MODE_FINGERPRINT_ENCODE](#abis_webservice2_mode_fingerprint_encode)
    - [ABIS_WEBSERVICE2_MODE_FINGERPRINT_RECODE](#abis_webservice2_mode_fingerprint_recode)
    - [ABIS_WEBSERVICE2_MODE_IRIS_ENCODE](#abis_webservice2_mode_iris_encode)
    - [ABIS_WEBSERVICE2_MODE_NFIQ](#abis_webservice2_mode_nfiq)
    - [ABIS_WEBSERVICE2_MODE_PALMPRINT_ENCODE](#abis_webservice2_mode_palmprint_encode)
    - [ABIS_WEBSERVICE2_MODE_PALMPRINT_RECODE](#abis_webservice2_mode_palmprint_recode)
    - [ABIS_WEBSERVICE2_MODE_TEMPLATE_ACCESS](#abis_webservice2_mode_template_access)
    - [ABIS_WEBSERVICE2_MODE_TEMPLATE_CONVERT](#abis_webservice2_mode_template_convert)
    - [ABIS_WEBSERVICE2_MODE_TEMPLATE_COMPARE](#abis_webservice2_mode_template_compare)
    - [ABIS_WEBSERVICE2_MODE_GROUP_ENCODE](#abis_webservice2_mode_group_encode)
    - [ABIS_WEBSERVICE2_MODE_ABIS_READ](#abis_webservice2_mode_abis_read)
    - [ABIS_WEBSERVICE2_MODE_ABIS_WRITE](#abis_webservice2_mode_abis_write)
    - [ABIS_WEBSERVICE2_MODE_ABIS_ASYNC](#abis_webservice2_mode_abis_async)
    - [ABIS_WEBSERVICE2_MODE_ABIS_STATUS](#abis_webservice2_mode_abis_status)
    - [ABIS_WEBSERVICE2_MODE_ABIS_RECORD](#abis_webservice2_mode_abis_record)
    - [DERMALOG_ABIS_VERSIONS_ABIS_WEBSERVICE2](#dermalog_abis_versions_abis_webservice2)
    - [DERMALOG_ABIS_VERSIONS_ABISFACEPLUGIN2](#dermalog_abis_versions_abisfaceplugin2)
    - [DERMALOG_ABIS_VERSIONS_ABISFINGERPLUGIN](#dermalog_abis_versions_abisfingerplugin)
    - [DERMALOG_ABIS_VERSIONS_ABISIRISPLUGIN](#dermalog_abis_versions_abisirisplugin)
    - [DERMALOG_ABIS_VERSIONS_ABISMATCHING](#dermalog_abis_versions_abismatching)
    - [DERMALOG_ABIS_VERSIONS_ABISPALMPLUGIN](#dermalog_abis_versions_abispalmplugin)
    - [ABIS_WEBSERVICE2_LOGGING_DATE_FORMAT](#abis_webservice2_logging_date_format)
    - [ABIS_WEBSERVICE2_ZMQ_LOG_LEVEL](#abis_webservice2_zmq_log_level)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs and configures the ABIS Webservice service.

## Requirements

none

## Role Variables

### ABIS_FUSIONS

Defines the fusion configurations to be used for matching requests.

**Please note** that this parameter is configured as a fact in the task *Determine ABIS fusions* of role *abis_common*.

For each fusion there is expected a hash with a name.
The name `Default` should be used for the default fusion.

Each hash is expected to have these attributes:

- `name`: The name of the ABIS Matching configuration.
- `threshold_verify`: The threshold used for verification requests.
- `threshold_search`: The threshold used for identification requests.

Example:

    ABIS_FUSIONS:
    'Default':
        'name': 'civil_demo'
        'threshold_verify': "{{ ABIS_COMMON_FUSIONS_WEBABIS_CIVIL_DEFAULT_THRESHOLD_VERIFY }}"
        'threshold_identify': "{{ ABIS_COMMON_FUSIONS_WEBABIS_CIVIL_DEFAULT_THRESHOLD_IDENTIFY }}"

Default: undefined

### ABIS_WEBSERVICE2_PACKAGES

Defines the packages that shall be installed by this role.

Default:

    ABIS_WEBSERVICE2_PACKAGES:
    - "dermalog-abis-webservice2-{{ DERMALOG_ABIS_VERSIONS_ABIS_WEBSERVICE2 }}"
    - "dermalog-abisfaceplugin-{{ DERMALOG_ABIS_VERSIONS_ABISFACEPLUGIN }}"
    # - dermalog-abisfaceplugin2
    # - dermalog-abisfingerplugin
    # - dermalog-abisirisplugin
    - "dermalog-abismatching-{{ DERMALOG_ABIS_VERSIONS_ABISMATCHING }}"
    # - dermalog-abispalmplugin
    - "dermalog-imagecontainer-{{ DERMALOG_ABIS_VERSIONS_IMAGECONTAINER }}"
    - "dermalog-fingercode3-{{ DERMALOG_ABIS_VERSIONS_FINGERCODE3 }}"
    - "dermalog-iriscode-{{ DERMALOG_ABIS_VERSIONS_IRISCODE }}"
    - "dermalog-palmcode-{{ DERMALOG_ABIS_VERSIONS_PALMCODE }}"
    - "dermalog-matchingresultaccessor-{{ DERMALOG_ABIS_VERSIONS_MATCHINGRESULTACCESSOR }}"
    - "dermalog-templateaccessor-{{ DERMALOG_ABIS_VERSIONS_TEMPLATEACCESSOR }}"
    - "dermalog-nistqualitycheck-{{ DERMALOG_ABIS_VERSIONS_NISTQUALITYCHECK }}"
    - "dermalog-formatansinist_itl1-{{ DERMALOG_ABIS_VERSIONS_FORMATANSINIST_ITL1 }}"
    - "dermalog-facesdk-backendproducts-{{ DERMALOG_ABIS_VERSIONS_FACESDK }}"

### ABIS_WEBSERVICE2_JAVA_HOME

Defines the Java home directory to start the service with.

Default:

    ABIS_WEBSERVICE2_JAVA_HOME: '/etc/alternatives/jre_11'

### ABIS_WEBSERVICE2_SERVICE_PORT

The port that provides the REST and monitoring endpoints.

Default:

    ABIS_WEBSERVICE2_SERVICE_PORT: 8080

### ABIS_WEBSERVICE2_CONTEXT_PATH

The context path of the service.

Default:

    ABIS_WEBSERVICE2_CONTEXT_PATH: '/v1'

### ABIS_WEBSERVICE2_SERVICE_MAX_THREADS

Defines the number of requests that can be processed in parallel.

When there are more incoming requests then the system will stall processing of the additional requests until threads are free for new
work.

Default:

    ABIS_WEBSERVICE2_SERVICE_MAX_THREADS: 200

### ABIS_WEBSERVICE2_CORS_ALLOWED_ORIGINS

Defines the allowed origins for Cross-Origin Resource Sharing (CORS).

If empty no cross origin is allowed. Multiple origins and wildcards are possible, separate them by comma.

Default:

    ABIS_WEBSERVICE2_CORS_ALLOWED_ORIGINS: ''

### ABIS_WEBSERVICE2_ABIS_READ_TARGET

The host and port where search and verification requests are forwarded to.

Default:

    ABIS_WEBSERVICE2_ABIS_READ_TARGET: 'tcp://127.0.0.1:5555'

### ABIS_WEBSERVICE2_ABIS_READ_TIMEOUT

Timeout in milliseconds. It applies to requests that are forwarded to abis_webservice2::abis_read_target.

Default:

    ABIS_WEBSERVICE2_ABIS_READ_TIMEOUT: 60000

### ABIS_WEBSERVICE2_ABIS_READ_ENCRYPTION_CLIENT_KEYS_PATH

The path to the folder containing the client key pair files - ``public.key``, ``private.key`` - used for encrypted communication with ``ABIS_WEBSERVICE2_ABIS_READ_TARGET``.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_WEBSERVICE2_ABIS_READ_ENCRYPTION_SERVER_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_WEBSERVICE2_ABIS_READ_ENCRYPTION_SERVER_KEYS_PATH

The path to the folder containing the public server key file - ``public.key`` - used for encrypted communication with ``ABIS_WEBSERVICE2_ABIS_READ_TARGET``.

The public key corresponds to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_WEBSERVICE2_ABIS_READ_ENCRYPTION_CLIENT_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_WEBSERVICE2_ASYNC_PERSISTENCE_FILE_BASEPATH

Defines the path where asynchronous requests are buffered.

Default:

    ABIS_WEBSERVICE2_ASYNC_PERSISTENCE_FILE_BASEPATH: /var/lib/dermalog/abis-webservice2/async-responses

### ABIS_WEBSERVICE2_ABIS_BIOMETRIC_TARGET

The host and port where template data will be read from.

Default:

    ABIS_WEBSERVICE2_ABIS_BIOMETRIC_TARGET: 'tcp://127.0.0.1:15000'

### ABIS_WEBSERVICE2_ABIS_BIOMETRIC_TIMEOUT

Timeout in milliseconds. It applies to requests that are forwarded to abis_webservice2::abis_biometric_target.

Default:

    ABIS_WEBSERVICE2_ABIS_BIOMETRIC_TIMEOUT: 60000

### ABIS_WEBSERVICE2_ABIS_BIOMETRIC_ENCRYPTION_CLIENT_KEYS_PATH

The path to the folder containing the client key pair files - ``public.key``, ``private.key`` - used for encrypted communication with ``ABIS_WEBSERVICE2_ABIS_BIOMETRIC_TARGET``.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_WEBSERVICE2_ABIS_BIOMETRIC_ENCRYPTION_SERVER_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_WEBSERVICE2_ABIS_BIOMETRIC_ENCRYPTION_SERVER_KEYS_PATH

The path to the folder containing the public server key file - ``public.key`` - used for encrypted communication with ``ABIS_WEBSERVICE2_ABIS_BIOMETRIC_TARGET``.

The public key corresponds to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_WEBSERVICE2_ABIS_BIOMETRIC_ENCRYPTION_CLIENT_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_WEBSERVICE2_ABIS_SPECIFIC_ACTION_TIMEOUTS

Some actions may take longer (e.g. a Search) or shall be finished in shorter times (e.g. a Verification).
This map defines timeouts in milliseconds specific to their action.\
These timeouts will override ``ABIS_WEBSERVICE2_ABIS_READ_TIMEOUT`` and ``ABIS_WEBSERVICE2_ABIS_BIOMETRIC_TIMEOUT``.

You may want to change the timeouts for ``Search``, ``Verification``, ``Insert`` or ``Delete``.

Default:

    ABIS_WEBSERVICE2_ABIS_SPECIFIC_ACTION_TIMEOUTS: {Search: 60000}

### ABIS_WEBSERVICE2_SEARCH_THRESHOLD

The default threshold for identification requests.

Default:

    ABIS_WEBSERVICE2_SEARCH_THRESHOLD: 50.0

### ABIS_WEBSERVICE2_VERIFY_THRESHOLD

The default threshold for verification requests.

Default:

    ABIS_WEBSERVICE2_VERIFY_THRESHOLD: 50.0

### ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_USE_SHAPE_CODING

Encode finger prints with shape meta data.

Default:

    ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_USE_SHAPE_CODING: true

### ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_USE_PATCH_DESCRIPTOR

Encode finger prints with patch descriptor meta data.

Default:

    ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_USE_PATCH_DESCRIPTOR: false

### ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_CORE_DELTA_DETECTION

This flag enables / disables core and delta detection during fingerprint encoding.

If no value is set the encoder default applies.

Default:

    ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_CORE_DELTA_DETECTION: undefined

### ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_USE_MINUTIAE_FILTER

If the parameter is set to True, it enables feature and Minutiae Filter Score (MFS) will be set.

Default:

    ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_USE_MINUTIAE_FILTER: true

### ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_MINUTIAE_FILTER_THRESHOLD

All minutiae with MFS < Threshold will be removed from template.

Used only when the value is set and ``ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_USE_MINUTIAE_FILTER`` is true.
If no value is set the encoder default applies.

Default:

    ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_MINUTIAE_FILTER_THRESHOLD: undefined

### ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_MINUTIAE_FILTER_MIN_MINUTIA

The parameter set a minimum number (n_min) of minutiae.

If available, at least the n_min best minutiae are kept, independent of their MFS.

Used only when the value is set and ``ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_USE_MINUTIAE_FILTER`` is true.
If no value is set the encoder default applies.

Default:

    ABIS_WEBSERVICE2_ENCODING_FINGERPRINT_MINUTIAE_FILTER_MIN_MINUTIA: undefined

### ABIS_WEBSERVICE2_ENCODING_FACE_ENCODING_TYPE

Data type: `Enum['STANDARD', 'MOBILE']`

If 'MOBILE' is defined, then there will be created face templates with limited FaceSDK feature for mobile devices.

**Please do not** mix up templates encoded with mobile and standard feature! Use one or the other in the whole system but not both!

Default:

    ABIS_WEBSERVICE2_ENCODING_FACE_ENCODING_TYPE: 'STANDARD'

### ABIS_WEBSERVICE2_ENCODING_FACE_PLATFORM

The platform to be utilized for encoding face templates.

- [`BEST`] for letting the FaceSDK detect automatically which inference plugin can be used by prefering the best possible choice (`GPU`
if license is available and hardware fits).
- [`CPU`] for using the cpu based inference plugin.
- [`GPU`] for using the gpu based inference plugin.

Default:

    ABIS_WEBSERVICE2_ENCODING_FACE_PLATFORM: 'BEST'

### ABIS_WEBSERVICE2_LIVELINESS_FACE_THRESHOLD

Threshold for liveliness evaluation, faces with scores above this threshold are considered 'alive'.

Default:

    ABIS_WEBSERVICE2_LIVELINESS_FACE_THRESHOLD: 60.0

### ABIS_WEBSERVICE2_TEMPLATE_VERIFICATION_WORKERS

The number of workers that will verify the templates before an insert or "upsert".

[`-1`]: automatic configuration

Default:

    ABIS_WEBSERVICE2_TEMPLATE_VERIFICATION_WORKERS: -1

### ABIS_WEBSERVICE2_LOCAL_PARALLEL_WORKERS

The number of parallel workers for all locally enabled modes (except the ABIS modes).

[`-1`]: automatic configuration

Default:

    ABIS_WEBSERVICE2_LOCAL_PARALLEL_WORKERS: -1

### ABIS_WEBSERVICE2_TARGET_SEARCH_MAX_ITEMS

The maximum allowed number of entries in search request with a given subset of records of the full dataset store in the ABIS Backend.

Default:

    ABIS_WEBSERVICE2_TARGET_SEARCH_MAX_ITEMS: 200

### ABIS_WEBSERVICE2_TARGET_SEARCH_THREADS

Number of threads that are utilized for target search requests.

Default:

    ABIS_WEBSERVICE2_TARGET_SEARCH_THREADS: 64

### ABIS_WEBSERVICE2_FALLBACK_VERIFICATION_ENABLED

If enabled there will be a fallback verification mode in case the ABIS Matching cluster is temporarily unavailable.

Default:

    ABIS_WEBSERVICE2_FALLBACK_VERIFICATION_ENABLED: true

### ABIS_WEBSERVICE2_FALLBACK_VERIFICATION_DURATION

The duration in milliseconds the fallback verification mode will be active in case the ABIS Matching cluster was unavailable.
This parameter will be ignored if ``ABIS_WEBSERVICE2_FALLBACK_VERIFICATION_ENABLED`` is disabled.

Default:

    ABIS_WEBSERVICE2_FALLBACK_VERIFICATION_DURATION: 300000

### ABIS_WEBSERVICE2_GROUPS

Map of position to name.

Example:

    ABIS_WEBSERVICE2_GROUPS: '[{"pos": 1, "name": "male" }, {"pos": 2, "name": "female" }]'

Default:

    ABIS_WEBSERVICE2_GROUPS: []

### ABIS_WEBSERVICE2_MODE_FACE_ENCODE

The endpoint */encode/face* is enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_FACE_ENCODE: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_FACE_FEATURE

The endpoint */feature/face* is enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_FACE_FEATURE: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_FACE_LIVELINESS

The endpoint */liveliness/face/detect* is enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_FACE_LIVELINESS: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_FACE_ICAO

The endpoint */icao/face* is enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_FACE_ICAO: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_FINGERPRINT_ENCODE

The endpoints */encode/fingerprint* and */encode/fingerprint/latent* are enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_FINGERPRINT_ENCODE: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_FINGERPRINT_RECODE

The endpoint */recode/fingerprint* is enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_FINGERPRINT_RECODE: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_IRIS_ENCODE

The endpoint */encode/iris* is enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_IRIS_ENCODE: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_NFIQ

The endpoint */nfiq2* is enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_NFIQ: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_PALMPRINT_ENCODE

The endpoints */encode/palm* and */encode/palm/latent* are enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_PALMPRINT_ENCODE: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_PALMPRINT_RECODE

The endpoints */recode/palm* and */recode/palm/latent* ere enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_PALMPRINT_RECODE: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_TEMPLATE_ACCESS

The endpoint */template/properties* is enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_TEMPLATE_ACCESS: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_TEMPLATE_CONVERT

The endpoints with names starting with */abis/template/convert* are enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_TEMPLATE_CONVERT: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_TEMPLATE_COMPARE

The endpoint */abis/template/compare* is enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_TEMPLATE_COMPARE: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_GROUP_ENCODE

The endpoint */encode/group* is enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_GROUP_ENCODE: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_ABIS_READ

The endpoints */abis/match* and */abis/verify* are enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_ABIS_READ: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_ABIS_WRITE

The endpoints */abis* and */abis/{recordId}* (for insert, upsert and delete) are enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_ABIS_WRITE: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_ABIS_ASYNC

The endpoints */abis/match/async* and */abis/match/async/{refId}* are enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_ABIS_ASYNC: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_ABIS_STATUS

The endpoints */abis/inactive* and */abis/status/{recordId}* are enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_ABIS_STATUS: 'LOCAL'

### ABIS_WEBSERVICE2_MODE_ABIS_RECORD

The endpoint */abis/{recordId}* (for reading an existing ABIS record) is enabled by setting to 'LOCAL' and disabled by 'DISABLED'.

Default:

    ABIS_WEBSERVICE2_MODE_ABIS_RECORD: 'LOCAL'

### DERMALOG_ABIS_VERSIONS_ABIS_WEBSERVICE2

Defines the version of the package to be installed.

Default: undefined

### DERMALOG_ABIS_VERSIONS_ABISFACEPLUGIN2

Defines the version of the package to be installed.

Default: undefined

### DERMALOG_ABIS_VERSIONS_ABISFINGERPLUGIN

Defines the version of the package to be installed.

Default: undefined

### DERMALOG_ABIS_VERSIONS_ABISIRISPLUGIN

Defines the version of the package to be installed.

Default: undefined

### DERMALOG_ABIS_VERSIONS_ABISMATCHING

Defines the version of the package to be installed.

Default: undefined

### DERMALOG_ABIS_VERSIONS_ABISPALMPLUGIN

Defines the version of the package to be installed.

Default: undefined

### ABIS_WEBSERVICE2_LOGGING_DATE_FORMAT

Defines the date/time format to be used for log entries.
By default there will be logged in UTC time.

Default:

    ABIS_WEBSERVICE2_LOGGING_DATE_FORMAT: >
      "yyyy-MM-dd'T'HH:mm:ss,SSSXXX", UTC

### ABIS_WEBSERVICE2_ZMQ_LOG_LEVEL

Defines the log level of ZeroMQ message logger.

Default:

    ABIS_WEBSERVICE2_ZMQ_LOG_LEVEL: 'WARN'

## Dependencies

- role: abis_common

## Example Playbook

Include the role in your playbook(s).

    - hosts: abismain
      roles:
        - role: abis_webservice2

Ensure that you have configure the ABIS Matching flavour.

    ABIS_COMMON_FLAVOUR: 'DEMO'

## License

proprietary
