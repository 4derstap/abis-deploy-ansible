# nist_converter

- [nist_converter](#nist_converter)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [NIST_CONVERTER_WEBSERVICE_JAVA_HOME](#nist_converter_webservice_java_home)
    - [NIST_CONVERTER_WEBSERVICE_SERVER_PORT](#nist_converter_webservice_server_port)
    - [NIST_CONVERTER_WEBSERVICE_CONTEXT_PATH](#nist_converter_webservice_context_path)
    - [NIST_CONVERTER_WEBSERVICE_CORS_ALLOWED_ORIGINS](#nist_converter_webservice_cors_allowed_origins)
    - [NIST_CONVERTER_WEBSERVICE_VERIFICATIONS_PATH](#nist_converter_webservice_verifications_path)
    - [NIST_CONVERTER_WEBSERVICE_XML_CONVERSIONS_PATH](#nist_converter_webservice_xml_conversions_path)
    - [NIST_CONVERTER_WEBSERVICE_DERMALOG_CONVERSIONS_PATH](#nist_converter_webservice_dermalog_conversions_path)
    - [NIST_CONVERTER_WEBSERVICE_MODE_NIST_READ](#nist_converter_webservice_mode_nist_read)
    - [NIST_CONVERTER_WEBSERVICE_MODE_NIST_WRITE](#nist_converter_webservice_mode_nist_write)
    - [NIST_CONVERTER_WEBSERVICE_LICENSE_LOCATION](#nist_converter_webservice_license_location)
    - [DERMALOG_ABIS_VERSIONS_NIST_CONVERTER_WEBSERVICE](#dermalog_abis_versions_nist_converter_webservice)
    - [NIST_CONVERTER_WEBSERVICE_LOGGING_DATE_FORMAT](#nist_converter_webservice_logging_date_format)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs and configures the NIST Converter service.

## Requirements

none

## Role Variables

### NIST_CONVERTER_WEBSERVICE_JAVA_HOME

The Java home directory.

Default:

    NIST_CONVERTER_WEBSERVICE_JAVA_HOME: '/etc/alternatives/jre_11'

### NIST_CONVERTER_WEBSERVICE_SERVER_PORT

The http port providing functional REST endpoints and endpoints for monitoring.

Default:

    NIST_CONVERTER_WEBSERVICE_SERVER_PORT: '8089'

### NIST_CONVERTER_WEBSERVICE_CONTEXT_PATH

The context path of the service.

Default:

    NIST_CONVERTER_WEBSERVICE_CONTEXT_PATH: '/v1'

### NIST_CONVERTER_WEBSERVICE_CORS_ALLOWED_ORIGINS

Defines the allowed origins for Cross-Origin Resource Sharing (CORS).

If empty no cross origin is allowed. Multiple origins and wildcards are possible, separate them by comma.

Default:

    NIST_CONVERTER_WEBSERVICE_CORS_ALLOWED_ORIGINS: ''

### NIST_CONVERTER_WEBSERVICE_VERIFICATIONS_PATH

Path to configuration files for the AWARE NISTPack SDK.

Default:

    NIST_CONVERTER_WEBSERVICE_VERIFICATIONS_PATH: '/etc/opt/dermalog/nist-converter-webservice/verifications/'

### NIST_CONVERTER_WEBSERVICE_XML_CONVERSIONS_PATH

Path to the required configuration files of the AWARE NISTPack SDK for converting NIST XML files.

Default:

    NIST_CONVERTER_WEBSERVICE_XML_CONVERSIONS_PATH: '/etc/opt/dermalog/nist-converter-webservice/conversion_schemas/'

### NIST_CONVERTER_WEBSERVICE_DERMALOG_CONVERSIONS_PATH

Path to the required conversion files of the DERMALOG NIST XML files converter.

Default:

    NIST_CONVERTER_WEBSERVICE_DERMALOG_CONVERSIONS_PATH: '/etc/opt/dermalog/nist-converter-webservice/dermalog_conversions/'

### NIST_CONVERTER_WEBSERVICE_MODE_NIST_READ

Defines the SDK to be used for parsing files in NIST format.

- `DERMALOG`: Use the DERMALOG implementation.
- `AWARE`: Use the AWARE NISTPack SDK.
- `DISABLED`: The read endpoint is disabled.

Default:

    NIST_CONVERTER_WEBSERVICE_MODE_NIST_READ: 'DERMALOG'

### NIST_CONVERTER_WEBSERVICE_MODE_NIST_WRITE

Defines the SDK to be used for writing files in NIST format.

- `DERMALOG`: Use the DERMALOG implementation.
- `AWARE`: Use the AWARE NISTPack SDK.
- `DISABLED`: The write endpoint is disabled.

Default:

    NIST_CONVERTER_WEBSERVICE_MODE_NIST_WRITE: 'DERMALOG'

### NIST_CONVERTER_WEBSERVICE_LICENSE_LOCATION

Path to the license file provided by AWARE when using the AWARE NISTPack SDK

Default: undefined

### DERMALOG_ABIS_VERSIONS_NIST_CONVERTER_WEBSERVICE

Defines the version of the package to be installed.

Default: undefined

### NIST_CONVERTER_WEBSERVICE_LOGGING_DATE_FORMAT

Defines the date/time format to be used for log entries.
By default there will be logged in UTC time.

Default:

    NIST_CONVERTER_WEBSERVICE_LOGGING_DATE_FORMAT: >
      "yyyy-MM-dd'T'HH:mm:ss,SSSXXX", UTC

## Dependencies

none

## Example Playbook

Include the role in your playbook(s) for all nodes that requires WIBU licenses.

    - hosts: nist_converter
      roles:
        - role: nist_converter

## License

proprietary
