# biometric_store

- [biometric_store](#biometric_store)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [BIOMETRIC_STORE_ZMQ_SEND_TIMEOUT](#biometric_store_zmq_send_timeout)
    - [BIOMETRIC_STORE_SERVICE_PORT](#biometric_store_service_port)
    - [BIOMETRIC_STORE_CLEANUP_CRON](#biometric_store_cleanup_cron)
    - [BIOMETRIC_STORE_DB_VARIANT](#biometric_store_db_variant)
    - [BIOMETRIC_STORE_DB_USERNAME](#biometric_store_db_username)
    - [BIOMETRIC_STORE_DB_PWD](#biometric_store_db_pwd)
    - [BIOMETRIC_STORE_DATASOURCE_URL](#biometric_store_datasource_url)
    - [BIOMETRIC_STORE_DB_POOL_SIZE](#biometric_store_db_pool_size)
    - [BIOMETRIC_STORE_ZMQ_ADDRESS](#biometric_store_zmq_address)
    - [BIOMETRIC_STORE_ZMQ_ENCRYPTION_KEYS_PATH](#biometric_store_zmq_encryption_keys_path)
    - [BIOMETRIC_STORE_PUBLISH_RECORD_CHANGES_ADDRESS](#biometric_store_publish_record_changes_address)
    - [BIOMETRIC_STORE_PUBLISH_RECORD_ENCRYPTION_KEYS_PATH](#biometric_store_publish_record_changes_encryption_keys_path)
    - [BIOMETRIC_STORE_PUBLISH_RECORD_CHANGES_REPETITION_CADENCE](#biometric_store_publish_record_changes_repetition_cadence)
    - [BIOMETRIC_STORE_ID_GENERATION_DATABASE_IDENTIFIER](#biometric_store_id_generation_database_identifier)
    - [BIOMETRIC_STORE_ID_GENERATION_GENERATION_SIZE](#biometric_store_id_generation_generation_size)
    - [BIOMETRIC_STORE_JAVA_HOME](#biometric_store_java_home)
    - [BIOMETRIC_STORE_LOGGING_DATE_FORMAT](#biometric_store_logging_date_format)
    - [BIOMETRIC_STORE_ZMQ_LOG_LEVEL](#biometric_store_zmq_log_level)
    - [DERMALOG_ABIS_VERSIONS_BIOMETRIC_STORE](#dermalog_abis_versions_biometric_store)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs and configures the BiometricStore service.

## Requirements

none

## Role Variables

### BIOMETRIC_STORE_ZMQ_SEND_TIMEOUT

The timeout in milliseconds for sending messages via ØMQ from the BiometricStore.

Default:

    BIOMETRIC_STORE_ZMQ_SEND_TIMEOUT: 2000

### BIOMETRIC_STORE_SERVICE_PORT

The http port providing monitoring functionality.

Default:

    BIOMETRIC_STORE_SERVICE_PORT: 8081

### BIOMETRIC_STORE_CLEANUP_CRON

Execute the clean up of obsolete records (records that are marked as deleted or left in an incomplete transaction state) as described by the cron expression.

Default:

    BIOMETRIC_STORE_CLEANUP_CRON: "0 0/5 * * * *"

### BIOMETRIC_STORE_DB_VARIANT

The variant of the BiometricStore database: `oracle`, `mysql`, `postgresql`, `h2`, `h2-embedded`

Default: undefined

### BIOMETRIC_STORE_DB_USERNAME

The username where the BiometricStore service expects the database objects.

Default: undefined

### BIOMETRIC_STORE_DB_PWD

The password that relates to biometric_store::db_username.

Default: undefined

### BIOMETRIC_STORE_DATASOURCE_URL

Configure the complete JDBC URL

Examples:

- Oracle: 'jdbc:oracle:thin:@//127.0.0.1/xe'
- MySQL: 'jdbc:mysql://127.0.0.1:3306/biometricstore'
- PostgreSQL: 'jdbc:postgresql://127.0.0.1:5432/biometricstore?currentSchema=schema'
- H2: 'jdbc:h2:tcp://localhost:1521/biometricstore'

Default: undefined

### BIOMETRIC_STORE_DB_POOL_SIZE

The maximum pool size for database connections.

Default:

    BIOMETRIC_STORE_DB_POOL_SIZE: 10

### BIOMETRIC_STORE_ZMQ_ADDRESS

The target URL for sending messages via ØMQ to the BiometricStore.

Default:

    BIOMETRIC_STORE_ZMQ_ADDRESS: 'tcp://localhost:15000'

### BIOMETRIC_STORE_ZMQ_ENCRYPTION_KEYS_PATH

The path to the folder containing the client key pair files - ``public.key``, ``private.key`` - used for encrypted communication with ``BIOMETRIC_STORE_ZMQ_ADDRESS``.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

Default: undefined

### BIOMETRIC_STORE_PUBLISH_RECORD_CHANGES_ADDRESS

Committed changes on records, e.g. inserts, upserts or deletes, will be published to this address.
Every interested and active subscriber will then receive a dedicated message with the changes.

Default:

    BIOMETRIC_STORE_PUBLISH_RECORD_CHANGES_ADDRESS: 'tcp://*:14999'

### BIOMETRIC_STORE_PUBLISH_RECORD_CHANGES_ENCRYPTION_KEYS_PATH

The path to the folder containing the client key pair files - ``public.key``, ``private.key`` - used for encrypted communication with ``BIOMETRIC_STORE_PUBLISH_RECORD_CHANGES_ADDRESS``.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

Default: undefined

### BIOMETRIC_STORE_PUBLISH_RECORD_CHANGES_REPETITION_CADENCE

The record changes will be repeatedly published in case a subscriber hasn't been available.
This list contains the delay of those repeated messages in seconds.

Default:

    BIOMETRIC_STORE_PUBLISH_RECORD_CHANGES_REPETITION_CADENCE: [60, 180, 540]

### BIOMETRIC_STORE_ID_GENERATION_DATABASE_IDENTIFIER

The value consists of two parts, the index of the database and the total number of involved databases, i.e.

&lt;Index&gt; / &lt;Total&gt;

If the BiometricStore is a single instance which runs against a single database the value shall be
the default value, '1/1'.
If you intend to scale the BiometricStore horizontally, running multiple instances of the BiometricStore but
still using a single database then the default value is also the way to go.
If you intend to run multiple instances of the BiometricStore, each with its own database and those
databases are synchronized, for example by GoldenGate, the default value will NOT do.
Lets say you have three BiometricStores each with its own database, then the value shall be '1/3', '2/3' and
'3/3' respectively.

Default:
    BIOMETRIC_STORE_ID_GENERATION_DATABASE_IDENTIFIER: '1/1'

### BIOMETRIC_STORE_ID_GENERATION_GENERATION_SIZE

The amount of IDs which shall be reserved each time a new ID chunk is requested.

Default:

    BIOMETRIC_STORE_ID_GENERATION_GENERATION_SIZE: 10000

### BIOMETRIC_STORE_JAVA_HOME

The Java home directory.

Default:

    BIOMETRIC_STORE_JAVA_HOME: '/etc/alternatives/jre_11'

### BIOMETRIC_STORE_LOGGING_DATE_FORMAT

Defines the date/time format to be used in the log files.

Default:

    BIOMETRIC_STORE_LOGGING_DATE_FORMAT: >
      "yyyy-MM-dd'T'HH:mm:ss,SSSXXX", UTC

### BIOMETRIC_STORE_ZMQ_LOG_LEVEL

Defines the log level of ZeroMQ message logger.

Default:

    BIOMETRIC_STORE_ZMQ_LOG_LEVEL: 'WARN'

### DERMALOG_ABIS_VERSIONS_BIOMETRIC_STORE

Defines the version of the package to be installed.

Default: undefined

## Dependencies

none

## Example Playbook

Include the role in your playbook(s).

    - hosts: abismain
      roles:
        - role: biometric_store

Configure the database connection details.

    BIOMETRIC_STORE_DB_VARIANT: 'mysql'
    BIOMETRIC_STORE_DATASOURCE_URL: 'jdbc:mysql://127.0.0.1:3306/BIOMETRICSTORE?useSSL=false'
    BIOMETRIC_STORE_DB_USERNAME: 'biometricstore'
    BIOMETRIC_STORE_DB_PWD: 'biometricstore'

## License

proprietary
