# abis_dispatcher

- [abis_dispatcher](#abis_dispatcher)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [ABIS_DISPATCHER_SYMBOLIC_NAME](#abis_dispatcher_symbolic_name)
    - [ABIS_DISPATCHER_MIN_SATELLITES](#abis_dispatcher_min_satellites)
    - [ABIS_DISPATCHER_MAX_SATELLITES](#abis_dispatcher_max_satellites)
    - [ABIS_DISPATCHER_WAIT_SATELLITES_GRACE_PERIOD](#abis_dispatcher_wait_satellites_grace_period)
    - [ABIS_DISPATCHER_NR_OF_GALLERIES](#abis_dispatcher_nr_of_galleries)
    - [ABIS_DISPATCHER_HEARTBEAT_TIMEOUT](#abis_dispatcher_heartbeat_timeout)
    - [ABIS_DISPATCHER_SEARCH_TIMEOUT](#abis_dispatcher_search_timeout)
    - [ABIS_DISPATCHER_SATELLITE_GALLERY_SIZE](#abis_dispatcher_satellite_gallery_size)
    - [ABIS_DISPATCHER_SATELLITE_HITLIST_SIZE](#abis_dispatcher_satellite_hitlist_size)
    - [ABIS_DISPATCHER_SATELLITE_POOL_THREADS](#abis_dispatcher_satellite_pool_threads)
    - [ABIS_DISPATCHER_SATELLITE_GALLERY_KIND](#abis_dispatcher_satellite_gallery_kind)
    - [ABIS_DISPATCHER_SNMP_ENABLE](#abis_dispatcher_snmp_enable)
    - [ABIS_DISPATCHER_SNMP_NAME](#abis_dispatcher_snmp_name)
    - [ABIS_DISPATCHER_ADMIN_BIND](#abis_dispatcher_admin_bind)
    - [ABIS_DISPATCHER_FRONTEND_BIND](#abis_dispatcher_frontend_bind)
    - [ABIS_DISPATCHER_SYNCHRONIZE_CONNECT](#abis_dispatcher_synchronize_connect)
    - [ABIS_DISPATCHER_SATELLITE_BIND](#abis_dispatcher_satellite_bind)
    - [ABIS_DISPATCHER_ENCRYPTION_SERVER_KEY_PATH](#abis_dispatcher_encryption_server_key_path)
    - [ABIS_DISPATCHER_SYNCHRONIZE_ENCRYPTION_KEYS_PATH](#abis_dispatcher_synchronize_encryption_keys_path)
    - [ABIS_DISPATCHER_LOG_LEVEL](#abis_dispatcher_log_level)
    - [ABIS_DISPATCHER_LOG_LEVEL_NETWORK](#abis_dispatcher_log_level_network)
    - [ABIS_DISPATCHER_LOG_ASYNC](#abis_dispatcher_log_async)
    - [ABIS_DISPATCHER_BIOMETRIC_STORE_BASE_URL](#abis_dispatcher_biometric_store_base_url)
    - [ABIS_DISPATCHER_ABISSYNC_STORE_BASE_URL](#abis_dispatcher_abissync_store_base_url)
    - [ABIS_DISPATCHER_LOGGING_DATE_FORMAT](#abis_dispatcher_logging_date_format)
    - [ABIS_DISPATCHER_CONVERSION_PATTERN](#abis_dispatcher_conversion_pattern)
    - [DERMALOG_ABIS_VERSIONS_ABIS_DISPATCHER](#dermalog_abis_versions_abis_dispatcher)
    - [ABIS_MATCHING_CONFIG_ROOT](#abis_matching_config_root)
    - [ABIS_MATCHING_CONFIGS](#abis_matching_configs)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs and configures the ABIS Matching Dispatcher.

## Requirements

none

## Role Variables

### ABIS_DISPATCHER_SYMBOLIC_NAME

The name as identity for connecting to ABIS Sync Service, this name must be **unique!**

Default:

    ABIS_DISPATCHER_SYMBOLIC_NAME: "{{ ansible_facts['hostname'] }}"

### ABIS_DISPATCHER_MIN_SATELLITES

The number of satellites required to setup operational cluster.

Default:

    ABIS_DISPATCHER_MIN_SATELLITES: 1

### ABIS_DISPATCHER_MAX_SATELLITES

The number of satellites allowed to join the cluster.

Default:

    ABIS_DISPATCHER_MAX_SATELLITES: 1

### ABIS_DISPATCHER_WAIT_SATELLITES_GRACE_PERIOD

The time in ms to wait for more satellite instance to join after minimum number of satellites have joined the matching cluster.

Default:

    ABIS_DISPATCHER_WAIT_SATELLITES_GRACE_PERIOD: 15000

### ABIS_DISPATCHER_NR_OF_GALLERIES

Determines the overall count of all galleries.

Default:

    ABIS_DISPATCHER_NR_OF_GALLERIES: 30

### ABIS_DISPATCHER_HEARTBEAT_TIMEOUT

Defines the heartbeat timeout in ms. If this value is reached this satellite will be dropped.

Default:

    ABIS_DISPATCHER_HEARTBEAT_TIMEOUT: 5000

### ABIS_DISPATCHER_SEARCH_TIMEOUT

Defines the search timeout in ms. If this value is reached this satellite will be dropped.

Default:

    ABIS_DISPATCHER_SEARCH_TIMEOUT: '24h'

### ABIS_DISPATCHER_SATELLITE_GALLERY_SIZE

Determines the gallery blob size for initial allocation (defined in MegaBytes).

Default:

    ABIS_DISPATCHER_SATELLITE_GALLERY_SIZE: 30

### ABIS_DISPATCHER_SATELLITE_HITLIST_SIZE

Limits the hitlist size for search requests.

Default:

    ABIS_DISPATCHER_SATELLITE_HITLIST_SIZE: 30

### ABIS_DISPATCHER_SATELLITE_POOL_THREADS

Determines the worker threads count

- [`0`]: the dermalog-abismatching-satellite determines the maximal cores given bei std::thread::hardware_concurrency
- [`< max(CPU Cores)`]: count of concurrent worker threads
- [`> max(CPU Cores)`]: should only be used if you know what you do!

Default:

    ABIS_DISPATCHER_SATELLITE_POOL_THREADS: 0

### ABIS_DISPATCHER_SATELLITE_GALLERY_KIND

Determines how the biometric data will be stored / handled.

- [`Memory`]: stores the gallery only in RAM
- [`MemoryMappedFile`]: stores the gallery in RAM and flush them to local harddisk or network attached storage, like GlusterFS, NFS, etc. After rebooting the galleries can be loaded from storage.

Default:

    ABIS_DISPATCHER_SATELLITE_GALLERY_KIND: Memory

### ABIS_DISPATCHER_SNMP_ENABLE

Switch to activate / deactivate the SNMP feature

Default:

    ABIS_DISPATCHER_SNMP_ENABLE: false

### ABIS_DISPATCHER_SNMP_NAME

The identifier for SNMP usage.

Default:

    ABIS_DISPATCHER_SNMP_NAME: 'abismatching-dispatcher'

### ABIS_DISPATCHER_ADMIN_BIND

The address for binding the admin interface.

Default:

    ABIS_DISPATCHER_ADMIN_BIND: 'tcp://*:5555'

### ABIS_DISPATCHER_FRONTEND_BIND

The address for binding the frontend interface to communicate with other services.

If the communication between the ABIS services shall be encrypted then you should configure this endpoint.
The ABIS Matching tool can then be used with the unsecured admin enpoint whereas the ABIS services use
this endpoint with encrypted communication.

Default: undefined

### ABIS_DISPATCHER_SYNCHRONIZE_CONNECT

The address to connect to the synchronization service. If the Dispatcher should be not synchronized leave it empty.

Default: 'tcp://localhost:16000'

### ABIS_DISPATCHER_SATELLITE_BIND

The binding interface for the satellites.

Default:

    ABIS_DISPATCHER_SATELLITE_BIND: 'tcp://*:6666'

### ABIS_DISPATCHER_ENCRYPTION_SERVER_KEY_PATH

The path to the folder containing the key file - `private.key` - used for encrypted communication with the endpoints defined by `ABIS_DISPATCHER_SATELLITE_BIND` and `ABIS_DISPATCHER_FRONTEND_BIND`.

The private key file is used by the server endpoint when encrypting connections from ABIS Matching Satellite service instances.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at  [NaCl: Networking and Cryptography library](https://nacl.cr.yp.to/valid.html).

Default: undefined

### ABIS_DISPATCHER_SYNCHRONIZE_ENCRYPTION_KEYS_PATH

The path to the folder containing the key files - `public.key`, `private.key` - used for encrypted communication with the endpoint defined by `ABIS_DISPATCHER_SYNCHRONIZE_CONNECT`.

The public key file identifies the server endpoint (ABIS Sync service) and relates to the servers private key file.
The private key file identifies the client (ABIS Matching Dispatcher).

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at  [NaCl: Networking and Cryptography library](https://nacl.cr.yp.to/valid.html).

Default: undefined

### ABIS_DISPATCHER_LOG_LEVEL

Defines the log level for normal general log entries.

Valid log levels are:

- [`ALL`]: The ALL LogLevel is used during configuration to turn on all logging.
- [`TRACE`]: The TRACE LogLevel is used to "trace" entry and exiting of methods.
- [`DEBUG`]: The DEBUG LogLevel designates fine-grained informational events that are most useful to debug an application.
- [`INFO`]: The INFO LogLevel designates informational messages that highlight the progress of the application at coarse-grained
level.
- [`WARN`]: The WARN LogLevel designates potentially harmful situations.
- [`ERROR`]: The ERROR LogLevel designates error events that might still allow the application to continue running.
- [`FATAL`]: The FATAL LogLevel designates very severe error events that will presumably lead the application to abort.
- [`OFF`]: turns off the logging at all.

Default:

    ABIS_DISPATCHER_LOG_LEVEL: 'INFO'

### ABIS_DISPATCHER_LOG_LEVEL_NETWORK

Defines the log level for network related log entries.

Valid log levels are:

- [`ALL`]: The ALL LogLevel is used during configuration to turn on all logging.
- [`TRACE`]: The TRACE LogLevel is used to "trace" entry and exiting of methods.
- [`DEBUG`]: The DEBUG LogLevel designates fine-grained informational events that are most useful to debug an application.
- [`INFO`]: The INFO LogLevel designates informational messages that highlight the progress of the application at coarse-grained
level.
- [`WARN`]: The WARN LogLevel designates potentially harmful situations.
- [`ERROR`]: The ERROR LogLevel designates error events that might still allow the application to continue running.
- [`FATAL`]: The FATAL LogLevel designates very severe error events that will presumably lead the application to abort.
- [`OFF`]: turns off the logging at all.

Default:

    ABIS_DISPATCHER_LOG_LEVEL_NETWORK: 'WARN'

### ABIS_DISPATCHER_LOG_ASYNC

Defines if the log entries shall be written directly or buffered.

Default:

    ABIS_DISPATCHER_LOG_ASYNC: false

### ABIS_DISPATCHER_BIOMETRIC_STORE_BASE_URL

The URL of the BiometricStore service to check for availability as prerequisite during service start.

Default:

    ABIS_DISPATCHER_BIOMETRIC_STORE_BASE_URL: 'http://localhost:8081'

### ABIS_DISPATCHER_ABISSYNC_STORE_BASE_URL

The URL of the ABIS Sync service to check for availability as prerequisite during service start.

Default:

    ABIS_DISPATCHER_ABISSYNC_STORE_BASE_URL: 'http://localhost:8087'

### ABIS_DISPATCHER_LOGGING_DATE_FORMAT

Defines the date/time format to be used for log entries.

By default there will be logged in UTC time.
If local time is required then change the default like this:

    ABIS_DISPATCHER_LOGGING_DATE_FORMAT: !unsafe '%D{%Y-%m-%dT%H:%M:%S,%q%z}'

See also the [log4cplus documentation about patterns](https://log4cplus.sourceforge.io/docs/api/2.0.x/classlog4cplus_1_1PatternLayout.html).

Default:

    ABIS_DISPATCHER_LOGGING_DATE_FORMAT: !unsafe '%d{%Y-%m-%dT%H:%M:%S,%q%z}'

### ABIS_DISPATCHER_CONVERSION_PATTERN

Defines the format pattern to be used for logging.

Default:

    ABIS_DISPATCHER_CONVERSION_PATTERN: "{{ ABIS_DISPATCHER_LOGGING_DATE_FORMAT }} dermalog-abismatching-dispatcher %p %X{requestId} %X{threadName} %c %m%n"

### DERMALOG_ABIS_VERSIONS_ABIS_DISPATCHER

Defines the version of the package to be installed.

Default: undefined

### ABIS_MATCHING_CONFIG_ROOT

Defines the folder where the ABIS Matching configuration files are loaded from.

Default:

    ABIS_MATCHING_CONFIG_ROOT: '/etc/opt/dermalog/abismatching/'

### ABIS_MATCHING_CONFIGS

Defines the ABIS Matching configuration files that shall be used in the matching cluster.

Default: undefined

## Dependencies

- role: abis_common

## Example Playbook

Include the role in your playbook(s).

    - hosts: abismain
      roles:
        - role: abis_dispatcher

Configure the endpoint of the ABIS Sync service and ensure you have a ABIS Matching configuration flavour defined.

    ABIS_COMMON_FLAVOUR: 'DEMO'
    ABIS_DISPATCHER_SYNCHRONIZE_CONNECT: 'tcp://127.0.0.1:16000'

## License

proprietary
