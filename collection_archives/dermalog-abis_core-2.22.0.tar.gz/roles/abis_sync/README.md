# abis_sync

- [abis_sync](#abis_sync)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [DERMALOG_ABIS_VERSIONS_ABIS_SYNC](#dermalog_abis_versions_abis_sync)
    - [ABIS_SYNC_SERVICE_JAVA_HOME](#abis_sync_service_java_home)
    - [ABIS_SYNC_SERVER_PORT](#abis_sync_server_port)
    - [ABIS_SYNC_ZMQ_RECV_TIMEOUT](#abis_sync_zmq_recv_timeout)
    - [ABIS_SYNC_ZMQ_RECV_TIMEOUT_LONG](#abis_sync_zmq_recv_timeout_long)
    - [ABIS_SYNC_SYNCING_THREADS](#abis_sync_syncing_threads)
    - [ABIS_SYNC_SYNC_CRON](#abis_sync_sync_cron)
    - [ABIS_SYNC_SERVICE_LISTENING_ADDRESS_TO_START_SYNCHRONIZATION](#abis_sync_service_listening_address_to_start_synchronization)
    - [ABIS_SYNC_SERVICE_LISTENING_ENCRYPTION_KEYS_PATH](#abis_sync_service_listening_encryption_keys_path)
    - [ABIS_SYNC_SERVICE_SYNC_ADDRESS_MASTER](#abis_sync_service_sync_address_master)
    - [ABIS_SYNC_SERVICE_SYNC_MASTER_ENCRYPTION_CLIENT_KEYS_PATH](#abis_sync_service_sync_master_encryption_client_keys_path)
    - [ABIS_SYNC_SERVICE_SYNC_MASTER_ENCRYPTION_SERVER_KEYS_PATH](#abis_sync_service_sync_master_encryption_server_keys_path)
    - [ABIS_SYNC_SERVICE_SYNC_ADDRESS_SLAVE](#abis_sync_service_sync_address_slave)
    - [ABIS_SYNC_SERVICE_SYNC_SLAVE_ENCRYPTION_CLIENT_KEYS_PATH](#abis_sync_service_sync_slave_encryption_client_keys_path)
    - [ABIS_SYNC_SERVICE_SYNC_SLAVE_ENCRYPTION_SERVER_KEYS_PATH](#abis_sync_service_sync_slave_encryption_server_keys_path)
    - [ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_SUBSCRIPTION_URLS](#abis_sync_subscribe_record_changes_subscription_urls)
    - [ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_ENCRYPTION_CLIENT_KEYS_PATH](#abis_sync_subscribe_record_changes_encryption_client_keys_path)
    - [ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_ENCRYPTION_SERVER_KEYS_PATH](#abis_sync_subscribe_record_changes_encryption_server_keys_path)
    - [ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_RETRY_DELAY](#abis_sync_subscribe_record_changes_retry_delay)
    - [ABIS_SYNC_POLLING_RECORD_CHANGES_INTERVAL](#abis_sync_polling_record_changes_interval)
    - [ABIS_SYNC_SERVICE_LOGGING_DATE_FORMAT](#abis_sync_service_logging_date_format)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs and configures the ABIS Sync service.

## Requirements

none

## Role Variables

### DERMALOG_ABIS_VERSIONS_ABIS_SYNC

The package version of the ABIS Sync service.

Default: undefined

### ABIS_SYNC_SERVICE_JAVA_HOME

Defines the JAVA_HOME to be used for starting the service.

Default:

`ABIS_SYNC_SERVICE_JAVA_HOME: '/etc/alternatives/jre_11'`

### ABIS_SYNC_SERVER_PORT

The http port providing monitoring functionality.

Default:

`ABIS_SYNC_SERVER_PORT: 8087`

### ABIS_SYNC_ZMQ_RECV_TIMEOUT

A timeout in seconds for all requests that are supposed to be answered quickly.

Default:

`ABIS_SYNC_ZMQ_RECV_TIMEOUT: 10`

### ABIS_SYNC_ZMQ_RECV_TIMEOUT_LONG

A timeout in seconds for all requests that are supposed to be answered slowly.

Default:

`ABIS_SYNC_ZMQ_RECV_TIMEOUT_LONG: 60`

### ABIS_SYNC_SYNCING_THREADS

Number of threads used for the synchronization.

Default:

`ABIS_SYNC_SYNCING_THREADS: 32`

### ABIS_SYNC_SYNC_CRON

This 6-field cron expression (second, minute, hour, day of month, month, day of week) defines the interval / start-times of the synchronization.
If a synchronization is currently running no additional synchronization will be started.

Default:

`ABIS_SYNC_SYNC_CRON: '0 0 1/24 * * *'`

### ABIS_SYNC_SERVICE_LISTENING_ADDRESS_TO_START_SYNCHRONIZATION

The endpoint where clients can request the synchronization.

Default:

`ABIS_SYNC_SERVICE_LISTENING_ADDRESS_TO_START_SYNCHRONIZATION: 'tcp://localhost:16000'`

### ABIS_SYNC_SERVICE_LISTENING_ENCRYPTION_KEYS_PATH

The path to the folder containing the client key pair files - ``public.key``, ``private.key`` - used for encrypted communication with ``ABIS_SYNC_SERVICE_LISTENING_ADDRESS_TO_START_SYNCHRONIZATION``.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

Default: undefined

### ABIS_SYNC_SERVICE_SYNC_ADDRESS_MASTER

The endpoint for the primary data store - usually the BiometricStore address.

Default:

`ABIS_SYNC_SERVICE_SYNC_ADDRESS_MASTER: 'tcp://localhost:15000'`

### ABIS_SYNC_SERVICE_SYNC_MASTER_ENCRYPTION_CLIENT_KEYS_PATH

The path to the folder containing the client key pair files - ``public.key``, ``private.key`` - used for encrypted communication with ``ABIS_SYNC_SERVICE_SYNC_ADDRESS_MASTER``.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_SYNC_SERVICE_SYNC_MASTER_ENCRYPTION_SERVER_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_SYNC_SERVICE_SYNC_MASTER_ENCRYPTION_SERVER_KEYS_PATH

The path to the folder containing the public server key file - ``public.key`` - used for encrypted communication with ``ABIS_SYNC_SERVICE_SYNC_ADDRESS_MASTER``.

The public key corresponds to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_SYNC_SERVICE_SYNC_MASTER_ENCRYPTION_CLIENT_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_SYNC_SERVICE_SYNC_ADDRESS_SLAVE

The endpoint for the synchronization target - usually the matching dispatcher.

Default:

`ABIS_SYNC_SERVICE_SYNC_ADDRESS_SLAVE: 'tcp://localhost:5555'`

### ABIS_SYNC_SERVICE_SYNC_SLAVE_ENCRYPTION_CLIENT_KEYS_PATH

The path to the folder containing the client key pair files - ``public.key``, ``private.key`` - used for encrypted communication with ``ABIS_SYNC_SERVICE_SYNC_ADDRESS_SLAVE``.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_SYNC_SERVICE_SYNC_SLAVE_ENCRYPTION_SERVER_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_SYNC_SERVICE_SYNC_SLAVE_ENCRYPTION_SERVER_KEYS_PATH

The path to the folder containing the public server key file - ``public.key`` - used for encrypted communication with ``ABIS_SYNC_SERVICE_SYNC_ADDRESS_SLAVE``.

The public key corresponds to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_SYNC_SERVICE_SYNC_SLAVE_ENCRYPTION_CLIENT_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_SUBSCRIPTION_URLS

The subscription addresses on which update messages on records will be published.

Default:

`ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_SUBSCRIPTION_URLS: ['tcp://localhost:14999']`

### ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_ENCRYPTION_CLIENT_KEYS_PATH

The path to the folder containing the client key pair files - ``public.key``, ``private.key`` - used for encrypted communication with ``ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_SUBSCRIPTION_URLS``.

Currently, only the same encryption is supported for all subscription targets.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_ENCRYPTION_SERVER_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_ENCRYPTION_SERVER_KEYS_PATH

The path to the folder containing the public server key file - ``public.key`` - used for encrypted communication with ``ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_SUBSCRIPTION_URLS``.

Currently, only the same encryption is supported for all subscription targets.

The public key corresponds to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_ENCRYPTION_CLIENT_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_RETRY_DELAY

The delay in seconds until a failed insert or delete operation of a changed record will be retried.

Default:

`ABIS_SYNC_SUBSCRIBE_RECORD_CHANGES_RETRY_DELAY: 60`

### ABIS_SYNC_POLLING_RECORD_CHANGES_INTERVAL

The interval in seconds in which the service checks for potentially missed update messages from master.

Default:

`ABIS_SYNC_POLLING_RECORD_CHANGES_INTERVAL: 1200`

### ABIS_SYNC_SERVICE_LOGGING_DATE_FORMAT

Defines the date/time format to be used for log entries.
By default there will be logged in UTC time.

Default:

    ABIS_SYNC_SERVICE_LOGGING_DATE_FORMAT: >
      "yyyy-MM-dd'T'HH:mm:ss,SSSXXX", UTC

## Dependencies

none

## Example Playbook

Include the role in your playbook(s).

    - hosts: abismain
      roles:
        - role: abis_sync

## License

proprietary
