# web_abis_biometric_sample_provider

- [web_abis_biometric_sample_provider](#web_abis_biometric_sample_provider)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_JAVA_HOME](#web_abis_biometric_sample_provider_java_home)
    - [WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_SERVER_PORT](#web_abis_biometric_sample_provider_server_port)
    - [WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_CONTEXT_PATH](#web_abis_biometric_sample_provider_context_path)
    - [WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_SERVICE_MAX_THREADS](#web_abis_biometric_sample_provider_service_max_threads)
    - [WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_VARIANT](#web_abis_biometric_sample_provider_db_variant)
    - [WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DATASOURCE_URL](#web_abis_biometric_sample_provider_datasource_url)
    - [WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_USERNAME](#web_abis_biometric_sample_provider_db_username)
    - [WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_PWD](#web_abis_biometric_sample_provider_db_pwd)
    - [WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_POOL_SIZE](#web_abis_biometric_sample_provider_db_pool_size)
    - [DERMALOG_ABIS_VERSIONS_WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER](#dermalog_abis_versions_web_abis_biometric_sample_provider)
    - [WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_LOGGING_DATE_FORMAT](#web_abis_biometric_sample_provider_logging_date_format)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role is intended to configure an instance of the dermalog-web-abis-biometric-sample-provider service.

## Requirements

none

## Role Variables

### WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_JAVA_HOME

The Java home directory.

Default:

    WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_JAVA_HOME: '/etc/alternatives/jre_11'

### WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_SERVER_PORT

The http port providing functional and monitoring endpoints.

Default:

    WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_SERVER_PORT: 10099

### WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_CONTEXT_PATH

The context path of the service.

Default:

    WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_CONTEXT_PATH: '/v1'

### WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_SERVICE_MAX_THREADS

Defines the number of requests that can be processed in parallel.

When there are more incoming requests then the system will stall processing of the additional requests until threads are free for new work.

Default:

    WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_SERVICE_MAX_THREADS: 200

### WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_VARIANT

The variant of the WebABIS database: `oracle`, `postgresql`, `mysql`, `h2`.

Default:

    WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_VARIANT: 'oracle'

### WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DATASOURCE_URL

The database URL for the WebABIS database.

Examples:

* Oracle: 'jdbc:oracle:thin:@//127.0.0.1/xe'
* MySQL: 'jdbc:mysql://127.0.0.1:3306/WEBABIS?useSSL=false'
* PostgreSQL: 'jdbc:postgresql://127.0.0.1:5432/webabis?currentSchema=schema'
* H2: 'jdbc:h2:tcp://localhost:1521/webabis'

Default: undefined

### WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_USERNAME

The database username.

Default: undefined

### WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_PWD

The passowrd of the database user.

Default: undefined

### WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_POOL_SIZE

The maximum pool size for database connections.

Default:

    WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_POOL_SIZE: 10

### DERMALOG_ABIS_VERSIONS_WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER

The version of the package to be installed.

Default: undefined

### WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_LOGGING_DATE_FORMAT

Defines the date/time format to be used for log entries.
By default there will be logged in UTC time.

Default:

    WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_LOGGING_DATE_FORMAT: >
      "yyyy-MM-dd'T'HH:mm:ss,SSSXXX", UTC

## Dependencies

none

## Example Playbook

Included the role in your playbook similar to this:

    - hosts: abismain
      roles:
        - role: web_abis_biometric_sample_provider

Configure the database connection details.

    WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DATASOURCE_URL: 'jdbc:mysql://127.0.0.1:3306/WEBABIS?useSSL=false'
    WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_VARIANT: 'mysql'
    WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_USERNAME: 'webabis'
    WEB_ABIS_BIOMETRIC_SAMPLE_PROVIDER_DB_PWD: 'webabis'

## License

proprietary
