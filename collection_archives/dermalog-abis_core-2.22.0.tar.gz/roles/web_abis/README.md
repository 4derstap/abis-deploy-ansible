# web_abis

- [web_abis](#web_abis)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [WEB_ABIS_JAVA_HOME](#web_abis_java_home)
    - [WEB_ABIS_SERVER_PORT](#web_abis_server_port)
    - [WEB_ABIS_CONTEXT_PATH](#web_abis_context_path)
    - [WEB_ABIS_SERVICE_MAX_THREADS](#web_abis_service_max_threads)
    - [WEB_ABIS_SAVE_MODALITY](#web_abis_save_modality)
    - [WEB_ABIS_ABIS_WEBSERVICE_URL](#web_abis_abis_webservice_url)
    - [WEB_ABIS_CORS_ALLOWED_ORIGINS](#web_abis_cors_allowed_origins)
    - [WEB_ABIS_DB_VARIANT](#web_abis_db_variant)
    - [WEB_ABIS_DATASOURCE_URL](#web_abis_datasource_url)
    - [WEB_ABIS_DB_USERNAME](#web_abis_db_username)
    - [WEB_ABIS_DB_PWD](#web_abis_db_pwd)
    - [WEB_ABIS_DB_POOL_SIZE](#web_abis_db_pool_size)
    - [WEB_ABIS_ID_GENERATION_DATABASE_IDENTIFIER](#web_abis_id_generation_database_identifier)
    - [WEB_ABIS_ID_GENERATION_GENERATION_SIZE](#web_abis_id_generation_generation_size)
    - [DERMALOG_ABIS_VERSIONS_WEB_ABIS](#dermalog_abis_versions_web_abis)
    - [WEB_ABIS_LOGGING_DATE_FORMAT](#web_abis_logging_date_format)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs and configures the WebABIS service.

## Requirements

none

## Role Variables

### WEB_ABIS_JAVA_HOME

The Java home directory.

Default:

    WEB_ABIS_JAVA_HOME: '/etc/alternatives/jre_11'

### WEB_ABIS_SERVER_PORT

The http port providing functional REST endpoints and endpoints for monitoring.

Default:

    WEB_ABIS_SERVER_PORT: 10000

### WEB_ABIS_CONTEXT_PATH

The context path of the service.

Default:

    WEB_ABIS_CONTEXT_PATH: '/v1'

### WEB_ABIS_SERVICE_MAX_THREADS

Defines the number of requests that can be processed in parallel.

When there are more incoming requests then the system will stall processing of the additional requests until threads are free for new work.

Default:

    WEB_ABIS_SERVICE_MAX_THREADS: 200

### WEB_ABIS_SAVE_MODALITY

Never change this value!

Whether the modality images will be persisted in the database or not.
If `false`, no image data will be available.
This will severely limit the functionality of WebABIS.
The read-identity endpoint will be not available.
All applications depending on the image data will not work, e.g. the WebABISFrontend.
Template migrations to new SDK versions will be more difficult or maybe even impossible.

Once this property has been set to `false` it can never be turned on again.

Default:

    WEB_ABIS_SAVE_MODALITY: true

### WEB_ABIS_ABIS_WEBSERVICE_URL

The URL of the ABIS Webservice that provides low level API endpoints of the ABIS Backend.

Default:

    WEB_ABIS_ABIS_WEBSERVICE_URL: 'http://localhost:8080/v1'

### WEB_ABIS_CORS_ALLOWED_ORIGINS

Defines the allowed origins for Cross-Origin Resource Sharing (CORS).

If not set or empty no cross origin is allowed, multiple origins are possible - separate them with a comma.

Default:

    WEB_ABIS_CORS_ALLOWED_ORIGINS: ''

### WEB_ABIS_DB_VARIANT

The variant of the WebABIS database: `oracle`, `postgresql`, `mysql`, `h2`, `h2-embedded`.

Default:

    WEB_ABIS_DB_VARIANT: 'oracle'

### WEB_ABIS_DATASOURCE_URL

Configure the complete JDBC URL

Examples:

* Oracle: 'jdbc:oracle:thin:@//127.0.0.1/xe'
* MySQL: 'jdbc:mysql://127.0.0.1:3306/WEBABIS?useSSL=false'
* PostgreSQL: 'jdbc:postgresql://127.0.0.1:5432/webabis?currentSchema=schema'
* H2: 'jdbc:h2:tcp://localhost:1521/webabis'

Default: undefined

### WEB_ABIS_DB_USERNAME

The username where the WebABIS service expects the database objects.

Default: undefined

### WEB_ABIS_DB_PWD

The password that relates to db_username.

Default: undefined

### WEB_ABIS_DB_POOL_SIZE

The maximum pool size for database connections.

Default:

    WEB_ABIS_DB_POOL_SIZE: 10

### WEB_ABIS_ID_GENERATION_DATABASE_IDENTIFIER

The value consists of two parts, the index of the database and the total number of involved databases, i.e.

&lt;Index&gt; / &lt;Total&gt;

If the WebABIS is a single instance which runs against a single database the value shall be the default value, '1/1'.
If you intend to scale the WebABIS horizontally, running multiple instances of the WebABIS but still using a single
database then the default value is also the way to go.
If you intend to run multiple instances of the WebABIS, each with its own database and those databases are
synchronized, for example by GoldenGate, the default value will NOT do.
Lets say you have three WebABIS each with its own database, then the value shall be '1/3', '2/3' and '3/3' respectively.

Default:

    WEB_ABIS_ID_GENERATION_DATABASE_IDENTIFIER: '1/1'

### WEB_ABIS_ID_GENERATION_GENERATION_SIZE

The amount of IDs which shall be reserved each time a new ID chunk is requested.

Default:

    WEB_ABIS_ID_GENERATION_GENERATION_SIZE: 10000

### DERMALOG_ABIS_VERSIONS_WEB_ABIS

Defines the version of the package to be installed.

Default: undefined

### WEB_ABIS_LOGGING_DATE_FORMAT

Defines the date/time format to be used for log entries.
By default there will be logged in UTC time.

Default:

    WEB_ABIS_LOGGING_DATE_FORMAT: >
      "yyyy-MM-dd'T'HH:mm:ss,SSSXXX", UTC

## Dependencies

none

## Example Playbook

Include the role in your playbook(s) for all nodes that require the WebABIS webservice.

    - hosts: abismain
      roles:
        - role: web_abis

Configure the database connection details.

    WEB_ABIS_DATASOURCE_URL: 'jdbc:mysql://127.0.0.1:3306/WEBABIS?useSSL=false'
    WEB_ABIS_DB_VARIANT: 'mysql'
    WEB_ABIS_DB_USERNAME: 'webabis'
    WEB_ABIS_DB_PWD: 'webabis'

## License

proprietary
