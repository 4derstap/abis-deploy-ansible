# snmp

- [snmp](#snmp)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [SNMP_PACKAGES](#snmp_packages)
    - [SNMP_DERMALOG_SERVICE_MIBS](#snmp_dermalog_service_mibs)
    - [SNMP_CONFIG](#snmp_config)
    - [SNMP_ROCOMMUNITY](#snmp_rocommunity)
    - [SNMP_VIEWS](#snmp_views)
    - [SNMP_AGENTX_TIMEOUT](#snmp_agentx_timeout)
    - [SNMP_AGENTX_RETRIES](#snmp_agentx_retries)
    - [SNMP_AGENTADDRESS](#snmp_agentaddress)
    - [SNMP_RO_COMMUNITY](#snmp_ro_community)
    - [SNMP_RO_NETWORK](#snmp_ro_network)
    - [SNMP_RO_COMMUNITY6](#snmp_ro_community6)
    - [SNMP_RO_NETWORK6](#snmp_ro_network6)
    - [SNMP_SNMPD_CONFIG](#snmp_snmpd_config)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs and configures the SNMP service.

## Requirements

none

## Role Variables

### SNMP_PACKAGES

Defines the list of packages to install.

Default:

    SNMP_PACKAGES:
      - net-snmp
      - net-snmp-libs
      - net-snmp-utils

### SNMP_DERMALOG_SERVICE_MIBS

Defines the MIB files that shall be used on the target node.

Default:

    SNMP_DERMALOG_SERVICE_MIBS:
      - mibs +DERMALOG-DISPATCHER-MIB
      - mibs +DERMALOG-SATELLITE-MIB

### SNMP_CONFIG

Defines the parameters to be added to the snmp.conf.

Default:

    SNMP_CONFIG: |-
      {{
        [
          'mibdirs +/opt/dermalog/mibs',
          'mibs +DERMALOG-SNMP-MIB',
        ] +
        SNMP_DERMALOG_SERVICE_MIBS +
        ['showMibErrors 1']
      }}

### SNMP_ROCOMMUNITY

Read-only (RO) array for agent and snmptrap daemon.

Default:

    SNMP_ROCOMMUNITY:
      - 'public'
      - 'public 127.0.0.1 .1.3.6.1.4.1.39157'

### SNMP_VIEWS

An array of views that are available to query.
Must provide VNAME, TYPE, OID, and [MASK].
See http://www.net-snmp.org/docs/man/snmpd.conf.html#lbAL for details.

Default:

    SNMP_VIEWS:
      - 'systemview included .1.3.6.1.2.1.1'
      - 'systemview included .1.3.6.1.2.1.25.1.1'
      - 'systemview included .1.3.6.1.4.1.39157'

### SNMP_AGENTX_TIMEOUT

Defines the timeout period (NUM seconds) for an AgentX request.

Default:

    SNMP_AGENTX_TIMEOUT: 1

### SNMP_AGENTX_RETRIES

Defines the number of retries for an AgentX request.

Default:

    SNMP_AGENTX_RETRIES: 5

### SNMP_AGENTADDRESS

Defines the listening endpoints of the agent-

Default:

    SNMP_AGENTADDRESS:
      - 'udp:127.0.0.1:161'
      - 'udp6:[::1]:161'

### SNMP_RO_COMMUNITY

Read-write (RW) community array agent.

Default:

    SNMP_RO_COMMUNITY:
      - public

### SNMP_RO_NETWORK

Network that is allowed to RO query the daemon. Is defined as array.

Default:

    SNMP_RO_NETWORK:
      - '127.0.0.1'

### SNMP_RO_COMMUNITY6

Read-write (RW) community array for IPv6 agent.

Default:

    SNMP_RO_COMMUNITY6:
      - public

### SNMP_RO_NETWORK6

Network that is allowed to RO query the daemon via IPv6. Is defined as array.

Default:

    SNMP_RO_NETWORK6:
      - '::1'

### SNMP_SNMPD_CONFIG

Array of lines to add to the snmpd.conf file.
See http://www.net-snmp.org/docs/man/snmpd.conf.html for all options.

Default:

    SNMP_SNMPD_CONFIG:
      - 'agentXPerms 664 777 root dermalog'
      - 'rocommunity public 127.0.0.1 .1.3.6.1.4.1.39157'

## Dependencies

none

## Example Playbook

Include the role in your playbook(s).

    - hosts: all
      roles:
        - role: dermalog.abis_core.snmp

## License

proprietary
