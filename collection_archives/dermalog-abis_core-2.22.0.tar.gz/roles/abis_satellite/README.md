# abis_satellite

- [abis_satellite](#abis_satellite)
  - [Requirements](#requirements)
  - [Role Tasks](#role-tasks)
    - [Delete_cache](#delete_cache)
  - [Role Variables](#role-variables)
    - [ABIS_SATELLITE_SYMBOLICNAME](#abis_satellite_symbolicname)
    - [ABIS_SATELLITE_ADMIN_BIND](#abis_satellite_admin_bind)
    - [ABIS_SATELLITE_GALLERY_DIR](#abis_satellite_gallery_dir)
    - [ABIS_SATELLITE_DISPATCHER_CONNECT](#abis_satellite_dispatcher_connect)
    - [ABIS_SATELLITE_ENCRYPTION_KEYS_PATH](#abis_satellite_encryption_keys_path)
    - [ABIS_SATELLITE_SNMP_ENABLE](#abis_satellite_snmp_enable)
    - [ABIS_SATELLITE_PACKAGES](#abis_satellite_packages)
    - [ABIS_SATELLITE_LOG_LEVEL_ABIS_SDK](#abis_satellite_log_level_abis_sdk)
    - [ABIS_SATELLITE_LOG_LEVEL](#abis_satellite_log_level)
    - [ABIS_SATELLITE_LOG_LEVEL_NETWORK](#abis_satellite_log_level_network)
    - [ABIS_SATELLITE_LOG_ASYNC](#abis_satellite_log_async)
    - [ABIS_SATELLITE_LOGGING_DATE_FORMAT](#abis_satellite_logging_date_format)
    - [ABIS_SATELLITE_CONVERSION_PATTERN](#abis_satellite_conversion_pattern)
    - [DERMALOG_ABIS_VERSIONS_ABISFACEPLUGIN2](#dermalog_abis_versions_abisfaceplugin2)
    - [DERMALOG_ABIS_VERSIONS_ABISFINGERPLUGIN](#dermalog_abis_versions_abisfingerplugin)
    - [DERMALOG_ABIS_VERSIONS_ABISIRISPLUGIN](#dermalog_abis_versions_abisirisplugin)
    - [DERMALOG_ABIS_VERSIONS_ABISMATCHING](#dermalog_abis_versions_abismatching)
    - [DERMALOG_ABIS_VERSIONS_ABIS_SATELLITE](#dermalog_abis_versions_abis_satellite)
    - [DERMALOG_ABIS_VERSIONS_ABISPALMPLUGIN](#dermalog_abis_versions_abispalmplugin)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs and configures the ABIS Matching Satellite.

## Requirements

none

## Role Tasks

### Delete_cache

Deletes cached galleries on satellites. Satellite service must not be running for this action to succeed.

## Role Variables

### ABIS_SATELLITE_SYMBOLICNAME

The name used to register at the dermalog-abismatching-dispatcher, this name must be **unique!**

Default:

    ABIS_SATELLITE_SYMBOLICNAME: "{{ ansible_facts['hostname'] }}"

### ABIS_SATELLITE_ADMIN_BIND

Defines the bind point for admin tool.

Default:

    ABIS_SATELLITE_ADMIN_BIND: 'tcp://*:5554'

### ABIS_SATELLITE_GALLERY_DIR

The directory where files with galleries for biometric templates are saved.

Default:

    ABIS_SATELLITE_GALLERY_DIR: '/var/lib/dermalog/abismatching-satellite/galleries'

### ABIS_SATELLITE_DISPATCHER_CONNECT

Defines the endpoint to connect to at the dermalog-abismatching-dispatcher.

Default:

    ABIS_SATELLITE_DISPATCHER_CONNECT: 'tcp://127.0.0.1:6666'

### ABIS_SATELLITE_ENCRYPTION_KEYS_PATH

The path to the folder containing the key files - `public.key`, `private.key` - used for encrypted communication with the endpoint defined by `ABIS_SATELLITE_DISPATCHER_CONNECT`.

The public key file identifies the server endpoint (ABIS Matching Dispatcher) and relates to its own private key file.
The private key file identifies the client (ABIS Matching Satellite).

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at  [NaCl: Networking and Cryptography library](https://nacl.cr.yp.to/valid.html).

Default: undefined

### ABIS_SATELLITE_SNMP_ENABLE

Switch to activate / deactivate the SNMP feature.

Default:

    ABIS_SATELLITE_SNMP_ENABLE: true

### ABIS_SATELLITE_PACKAGES

Defines the packages that shall be installed by this role.

Default:

    ABIS_SATELLITE_PACKAGES:
    - "dermalog-abismatching-satellite-{{ DERMALOG_ABIS_VERSIONS_ABIS_SATELLITE }}"
    - "dermalog-abisfaceplugin-{{ DERMALOG_ABIS_VERSIONS_ABISFACEPLUGIN }}"
    # - dermalog-abisfaceplugin2
    # - dermalog-abisfingerplugin
    # - dermalog-abisirisplugin
    - "dermalog-abismatching-{{ DERMALOG_ABIS_VERSIONS_ABISMATCHING }}"
    # - dermalog-abispalmplugin

### ABIS_SATELLITE_LOG_LEVEL_ABIS_SDK

Defines the ABISMatchingSDK log level.

Default:

    ABIS_SATELLITE_LOG_LEVEL_ABIS_SDK: 'INFO'

### ABIS_SATELLITE_LOG_LEVEL

Defines the log level of the ABIS Matching Satellite.

Valid log levels are:

- [`ALL`]: The ALL LogLevel is used during configuration to turn on all logging.
- [`TRACE`]: The TRACE LogLevel is used to "trace" entry and exiting of methods.
- [`DEBUG`]: The DEBUG LogLevel designates fine-grained informational events that are most useful to debug an application.
- [`INFO`]: The INFO LogLevel designates informational messages that highlight the progress of the application at coarse-grained
level.
- [`WARN`]: The WARN LogLevel designates potentially harmful situations.
- [`ERROR`]: The ERROR LogLevel designates error events that might still allow the application to continue running.
- [`FATAL`]: The FATAL LogLevel designates very severe error events that will presumably lead the application to abort.
- [`OFF`]: turns off the logging at all.

Default:

    ABIS_SATELLITE_LOG_LEVEL: 'INFO'

### ABIS_SATELLITE_LOG_LEVEL_NETWORK

Data type: `Enum['ALL', 'TRACE', 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL', 'OFF']`

Defines the log level for network related log entries.

Default:

    ABIS_SATELLITE_LOG_LEVEL_NETWORK: 'WARN'

### ABIS_SATELLITE_LOG_ASYNC

Defines if the log entries shall be written directly or buffered.

Default:

    ABIS_SATELLITE_LOG_ASYNC: false

### ABIS_SATELLITE_LOGGING_DATE_FORMAT

Defines the date/time format to be used for log entries.

By default there will be logged in UTC time.
If local time is required then change the default like this:

    ABIS_SATELLITE_LOGGING_DATE_FORMAT: !unsafe '%D{%Y-%m-%dT%H:%M:%S,%q%z}'

See also the [log4cplus documentation about patterns](https://log4cplus.sourceforge.io/docs/api/2.0.x/classlog4cplus_1_1PatternLayout.html).

Default:

    ABIS_SATELLITE_LOGGING_DATE_FORMAT: !unsafe '%d{%Y-%m-%dT%H:%M:%S,%q%z}'

### ABIS_SATELLITE_CONVERSION_PATTERN

Defines the format pattern that shall be used for creating log entries.

Default:

    ABIS_SATELLITE_CONVERSION_PATTERN: "{{ ABIS_SATELLITE_LOGGING_DATE_FORMAT }} dermalog-abismatching-satellite %p %X{requestId} %X{threadName} %c %m%n"

### DERMALOG_ABIS_VERSIONS_ABISFACEPLUGIN2

Defines the version of the ABIS Face Matching plugin that shall be installed.

Default: undefined

### DERMALOG_ABIS_VERSIONS_ABISFINGERPLUGIN

Defines the version of the package to be installed.

Default: undefined

### DERMALOG_ABIS_VERSIONS_ABISIRISPLUGIN

Defines the version of the package to be installed.

Default: undefined

### DERMALOG_ABIS_VERSIONS_ABISMATCHING

Defines the version of the ABIS Matching SDK that shall be installed.

Default: undefined

### DERMALOG_ABIS_VERSIONS_ABIS_SATELLITE

Defines the version of the ABIS Matching Satellite that shall be installed.

Default: undefined

### DERMALOG_ABIS_VERSIONS_ABISPALMPLUGIN

Defines the version of the package to be installed.

Default: undefined

## Dependencies

none

## Example Playbook

Include the role in your playbook(s).

    - hosts: satellites
      roles:
        - role: abis_satellite

Ensure you configured the correct endpoint in order to connect to let service connect to the ABIS Matching Dispatcher.

    ABIS_MAIN: 'abismain'
    ABIS_SATELLITE_DISPATCHER_CONNECT: "tcp://{{ ABIS_MAIN }}:6666"

## License

proprietary
