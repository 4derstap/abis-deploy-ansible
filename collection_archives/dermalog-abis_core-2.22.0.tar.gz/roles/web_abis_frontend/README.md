# web_abis_frontend

- [web_abis_frontend](#web_abis_frontend)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [WEB_ABIS_FRONTEND_JAVA_HOME](#web_abis_frontend_java_home)
    - [WEB_ABIS_FRONTEND_SERVER_PORT](#web_abis_frontend_server_port)
    - [WEB_ABIS_FRONTEND_PAGE_PERMISSIONS](#web_abis_frontend_page_permissions)
    - [WEB_ABIS_FRONTEND_WEB_ABIS_URL](#web_abis_frontend_web_abis_url)
    - [WEB_ABIS_FRONTEND_IDENTITY_TEMPLATE_API_ENABLED](#web_abis_frontend_identity_template_api_enabled)
    - [WEB_ABIS_FRONTEND_IDENTITY_TEMPLATE_API_URL](#web_abis_frontend_identity_template_api_url)
    - [WEB_ABIS_FRONTEND_WEB_ABIS_DB_VARIANT](#web_abis_frontend_web_abis_db_variant)
    - [WEB_ABIS_FRONTEND_WEB_ABIS_DATASOURCE_URL](#web_abis_frontend_web_abis_datasource_url)
    - [WEB_ABIS_FRONTEND_WEB_ABIS_DB_USERNAME](#web_abis_frontend_web_abis_db_username)
    - [WEB_ABIS_FRONTEND_WEB_ABIS_DB_PWD](#web_abis_frontend_web_abis_db_pwd)
    - [WEB_ABIS_FRONTEND_WEB_ABIS_DB_POOL_SIZE](#web_abis_frontend_web_abis_db_pool_size)
    - [DERMALOG_ABIS_VERSIONS_WEB_ABIS_FRONTEND](#dermalog_abis_versions_web_abis_frontend)
    - [WEB_ABIS_FRONTEND_LOGGING_DATE_FORMAT](#web_abis_frontend_logging_date_format)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role configures the WebABIS Frontend service.

## Requirements

none

## Role Variables

### WEB_ABIS_FRONTEND_JAVA_HOME

The Java home directory.

Default:

    WEB_ABIS_FRONTEND_JAVA_HOME: '/etc/alternatives/jre_11'

### WEB_ABIS_FRONTEND_SERVER_PORT

The http port providing the frontend.

Default:

    WEB_ABIS_FRONTEND_SERVER_PORT: '11000'

### WEB_ABIS_FRONTEND_PAGE_PERMISSIONS

A list of all page groups that will be available in the WebABIS Frontend.

The possible values are: 'demo', 'identity' and 'match'.

Default:

    WEB_ABIS_FRONTEND_PAGE_PERMISSIONS: ['demo']

### WEB_ABIS_FRONTEND_WEB_ABIS_URL

The URL of the WebABIS.

Default:

    WEB_ABIS_FRONTEND_WEB_ABIS_URL: 'http://localhost:10000/v1'

### WEB_ABIS_FRONTEND_ABIS_WEBSERVICE_URL

The URL of the ABIS Webservice.

Default:

    WEB_ABIS_FRONTEND_ABIS_WEBSERVICE_URL: 'http://localhost:8080/v1'

### WEB_ABIS_FRONTEND_IDENTITY_TEMPLATE_API_ENABLED

The Identity Template API enables access to the templates of an identity.
It is a mandatory API.

If `true` access to the WebABIS database is necessary.
Specify the WebABIS database config accordingly.

Use `false` if no direct access to the WebABIS database is possible, e.g. because of firewall, security, etc.
An alternative route to an available Identity Template API is then necessary.

Default:

    WEB_ABIS_FRONTEND_IDENTITY_TEMPLATE_API_ENABLED: true

### WEB_ABIS_FRONTEND_IDENTITY_TEMPLATE_API_URL

An alternative route to an available Identity Template API.

Only specify if `WEB_ABIS_FRONTEND_IDENTITY_TEMPLATE_API_ENABLED` is disabled.

Default: undefined

### WEB_ABIS_FRONTEND_WEB_ABIS_DB_VARIANT

The variant of the WebABIS database.

Only specify if `WEB_ABIS_FRONTEND_IDENTITY_TEMPLATE_API_ENABLED` is enabled.

Default: undefined

### WEB_ABIS_FRONTEND_WEB_ABIS_DATASOURCE_URL

The JDBC URL of the WebABIS database.

Only specify if `WEB_ABIS_FRONTEND_IDENTITY_TEMPLATE_API_ENABLED` is enabled.

Examples:

* Oracle: `jdbc:oracle:thin:@//127.0.0.1/xe`
* MySQL: `jdbc:mysql://127.0.0.1:3306/WEBABIS?useSSL=false`
* PostgreSQL: `jdbc:postgresql://127.0.0.1:5432/webabis?currentSchema=schema`
* H2: `jdbc:h2:tcp://localhost:1521/webabis`

Default: undefined

### WEB_ABIS_FRONTEND_WEB_ABIS_DB_USERNAME

The username of the WebABIS database.

Only specify if `WEB_ABIS_FRONTEND_IDENTITY_TEMPLATE_API_ENABLED` is enabled.

Default: undefined

### WEB_ABIS_FRONTEND_WEB_ABIS_DB_PWD

The password of the WebABIS database that relates to `WEB_ABIS_FRONTEND_WEB_ABIS_DB_USERNAME`.

Only specify if `WEB_ABIS_FRONTEND_IDENTITY_TEMPLATE_API_ENABLED` is enabled.

Default: undefined

### WEB_ABIS_FRONTEND_WEB_ABIS_DB_POOL_SIZE

The maximum pool size of the WebABIS database connections.

Optional value if `WEB_ABIS_FRONTEND_IDENTITY_TEMPLATE_API_ENABLED` is enabled.

Default: undefined

### DERMALOG_ABIS_VERSIONS_WEB_ABIS_FRONTEND

Defines the version of the package to be installed.

Default: undefined

### WEB_ABIS_FRONTEND_LOGGING_DATE_FORMAT

Defines the date/time format to be used for log entries.
By default there will be logged in UTC time.

Default:

    WEB_ABIS_FRONTEND_LOGGING_DATE_FORMAT: >
      "yyyy-MM-dd'T'HH:mm:ss,SSSXXX", UTC

## Dependencies

none

## Example Playbook

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: web_abis_frontend
      roles:
        - role: web_abis_frontend

## License

proprietary
