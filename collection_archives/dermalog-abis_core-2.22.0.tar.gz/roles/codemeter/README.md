# codemeter

- [codemeter](#codemeter)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [ABSENT_SERVERS](#absent_servers)
    - [WIBU_SERVER](#wibu_server)
    - [DERMALOG_ABIS_VERSIONS_CODEMETER](#dermalog_abis_versions_codemeter)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs and configures the WIBU Codemeter service.

## Requirements

none

## Role Variables

### ABSENT_SERVERS

Defines the list of servers that shall be removed from the server search list.

Default:

    ABSENT_SERVERS: []

### WIBU_SERVER

Defines the WIBU Codemeter server search list.

Default:

    WIBU_SERVER: []

### DERMALOG_ABIS_VERSIONS_CODEMETER

Defines the version that shall be installed.

Default: undefined

## Dependencies

none

## Example Playbook

Include the role in your playbook(s) for all nodes that requires WIBU licenses.

    - hosts: all
      roles:
        - role: codemeter

Ensure that you have configured a list of nodes to pull licenses from if they are provided on the same node.

    WIBU_SERVER:
      - shhapp206

## License

proprietary
