# web_abis_nist_extension

- [web_abis_nist_extension](#web_abis_nist_extension)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [WEB_ABIS_NIST_JAVA_HOME](#web_abis_nist_java_home)
    - [WEB_ABIS_NIST_SERVER_PORT](#web_abis_nist_server_port)
    - [WEB_ABIS_NIST_CONTEXT_PATH](#web_abis_nist_context_path)
    - [WEB_ABIS_NIST_WEB_ABIS_WEBSERVICE_URL](#web_abis_nist_web_abis_webservice_url)
    - [WEB_ABIS_NIST_NIST_CONVERTER_WEBSERVICE_URL](#web_abis_nist_nist_converter_webservice_url)
    - [WEB_ABIS_NIST_CORS_ALLOWED_ORIGINS](#web_abis_nist_cors_allowed_origins)
    - [WEB_ABIS_NIST_FINGERPRINT_SUPPORT](#web_abis_nist_fingerprint_support)
    - [WEB_ABIS_NIST_PALMPRINT_SUPPORT](#web_abis_nist_palmprint_support)
    - [WEB_ABIS_NIST_FACE_SUPPORT](#web_abis_nist_face_support)
    - [DERMALOG_ABIS_VERSIONS_WEB_ABIS_NIST](#dermalog_abis_versions_web_abis_nist)
    - [WEB_ABIS_NIST_LOGGING_DATE_FORMAT](#web_abis_nist_logging_date_format)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role configures the WebABIS NIST Extension web service.

## Requirements

none

## Role Variables

### WEB_ABIS_NIST_JAVA_HOME

The Java home directory.

Default:

    WEB_ABIS_NIST_JAVA_HOME: '/etc/alternatives/jre_11'

### WEB_ABIS_NIST_SERVER_PORT

The http port providing REST endpoints and monitoring functionality.

Default:

    WEB_ABIS_NIST_SERVER_PORT: '10001'

### WEB_ABIS_NIST_CONTEXT_PATH

The context path of the service.

Default:

    WEB_ABIS_NIST_CONTEXT_PATH: '/v1'

### WEB_ABIS_NIST_WEB_ABIS_WEBSERVICE_URL

The URL of the WebABIS Webservice that provides WebABIS Backend endpoints.

Default:

    WEB_ABIS_NIST_WEB_ABIS_WEBSERVICE_URL: 'http://localhost:10000/v1'

### WEB_ABIS_NIST_NIST_CONVERTER_WEBSERVICE_URL

The URL of the NISTConverter Webservice that provides endpoints to convert NIST files.

Default:

    WEB_ABIS_NIST_NIST_CONVERTER_WEBSERVICE_URL: 'http://localhost:8089/v1'

### WEB_ABIS_NIST_CORS_ALLOWED_ORIGINS

Defines the allowed origins for Cross-Origin Resource Sharing (CORS).

If not set or empty no cross origin is allowed, multiple origins are possible - separate them with a comma.

Default:

    WEB_ABIS_NIST_CORS_ALLOWED_ORIGINS: ''

### WEB_ABIS_NIST_FINGERPRINT_SUPPORT

When false then fingerprint records contained in a NIST file are ignored for any operation/endpoint.

Default:

    WEB_ABIS_NIST_FINGERPRINT_SUPPORT: true

### WEB_ABIS_NIST_PALMPRINT_SUPPORT

When false then palmprint records contained in a NIST file are ignored for any operation/endpoint.

Default:

    WEB_ABIS_NIST_PALMPRINT_SUPPORT: true

### WEB_ABIS_NIST_FACE_SUPPORT

When false then face records contained in a NIST file are ignored for any operation/endpoint.

Default:

    WEB_ABIS_NIST_FACE_SUPPORT: true

### DERMALOG_ABIS_VERSIONS_WEB_ABIS_NIST

Defines the version of the package to be installed.

Default: undefined

### WEB_ABIS_NIST_LOGGING_DATE_FORMAT

Defines the date/time format to be used for log entries.
By default there will be logged in UTC time.

Default:

    WEB_ABIS_NIST_LOGGING_DATE_FORMAT: >
      "yyyy-MM-dd'T'HH:mm:ss,SSSXXX", UTC

## Dependencies

none

## Example Playbook

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: web_abis_nist_extension
      roles:
        - role: web_abis_nist_extension

## License

proprietary
