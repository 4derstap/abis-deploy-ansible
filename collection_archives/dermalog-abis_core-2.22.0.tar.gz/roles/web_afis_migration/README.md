# web_afis_migration

- [web_afis_migration](#web_afis_migration)
    - [Requirements](#requirements)
    - [Role Variables](#role-variables)
        - [WEBAFIS_MIGRATION_JAVA_HOME](#webafis_migration_java_home)
        - [WEBAFIS_MIGRATION_CONTINUOUS_MIGRATION_ENABLED](#webafis_migration_continuous_migration_enabled)
        - [WEBAFIS_MIGRATION_CONTINUOUS_MIGRATION_CRON_SCHEDULE](#webafis_migration_continuous_migration_cron_schedule)
        - [WEBAFIS_MIGRATION_MIGRATION_THREADS](#webafis_migration_migration_threads)
        - [WEBAFIS_MIGRATION_MIGRATION_THREADS_EXCEPTIONS](#webafis_migration_migration_threads_exceptions)
        - [WEBAFIS_MIGRATION_MIGRATION_LOG_RATE](#webafis_migration_migration_log_rate)
        - [WEBAFIS_MIGRATION_WEB_ABIS_WEBSERVICE_URL](#webafis_migration_web_abis_webservice_url)
        - [WEBAFIS_MIGRATION_WEB_AFIS_JDBC_URL](#webafis_migration_web_afis_jdbc_url)
        - [WEBAFIS_MIGRATION_WEB_AFIS_DATASOURCE_USERNAME](#webafis_migration_web_afis_datasource_username)
        - [WEBAFIS_MIGRATION_WEB_AFIS_DATASOURCE_PASSWORD](#webafis_migration_web_afis_datasource_password)
        - [WEBAFIS_MIGRATION_WEB_ABIS_JDBC_URL](#webafis_migration_web_abis_jdbc_url)
        - [WEBAFIS_MIGRATION_WEB_ABIS_DATASOURCE_USERNAME](#webafis_migration_web_abis_datasource_username)
        - [WEBAFIS_MIGRATION_WEB_ABIS_DATASOURCE_PASSWORD](#webafis_migration_web_abis_datasource_password)
        - [WEBAFIS_MIGRATION_WEB_ABIS_DATASOURCE_DB_VARIANT](#webafis_migration_web_abis_datasource_db_variant)
        - [WEBAFIS_MIGRATION_LOGGING_DATE_FORMAT](#webafis_migration_logging_date_format)
        - [DERMALOG_ABIS_VERSIONS_WEB_AFIS_MIGRATION](#dermalog_abis_versions_web_afis_migration)
    - [Dependencies](#dependencies)
    - [Example Playbook](#example-playbook)
    - [License](#license)

This role installs and configures the WebAFISMigration service.

## Requirements

none

## Role Variables

### WEBAFIS_MIGRATION_JAVA_HOME

The Java home directory.

Default:

    WEBAFIS_MIGRATION_JAVA_HOME: '/etc/alternatives/jre_11'

### WEBAFIS_MIGRATION_CONTINUOUS_MIGRATION_ENABLED

Whether the migration shall restart after a successful run or not.
If `true` the slave is always kept up to date.

Default:

    WEBAFIS_MIGRATION_CONTINUOUS_MIGRATION_ENABLED: false

### WEBAFIS_MIGRATION_CONTINUOUS_MIGRATION_CRON_SCHEDULE

If continuous migration is enabled this 6-field cron expression (second, minute, hour, day of month, month, day of week) defines the interval / start-times of the migrations.

If a migration is still running no additional migration will be started.

Default:

    WEBAFIS_MIGRATION_CONTINUOUS_MIGRATION_CRON_SCHEDULE: '0 0/20 * * * *'

### WEBAFIS_MIGRATION_MIGRATION_THREADS

The number of threads the migration runs with.

Default:

    WEBAFIS_MIGRATION_MIGRATION_THREADS: 32

### WEBAFIS_MIGRATION_MIGRATION_THREADS_EXCEPTIONS

Define additional times when the default number of threads will not apply. E.g. on night time additional threads are possible.
The system clock applies for the defined time ranges.

Define the exceptions as key-value pairs, where the key is the time range and the value is the number of migration threads,
like this: ``{'21:00-05:00': 64, '11:30-14:00': 16}``

Default: undefined

### WEBAFIS_MIGRATION_MIGRATION_LOG_RATE

The interval in seconds the migration status is logged to the status log.

Default:

    WEBAFIS_MIGRATION_MIGRATION_LOG_RATE: 120

### WEBAFIS_MIGRATION_WEB_ABIS_WEBSERVICE_URL

The URL at which the WebABIS RESTful-API can be reached.

Default:

    WEBAFIS_MIGRATION_WEB_ABIS_WEBSERVICE_URL: 'http://localhost:10000/v1'

### WEBAFIS_MIGRATION_WEB_AFIS_JDBC_URL

Configure the complete JDBC URL of the WebAFIS database, e.g.: `jdbc:oracle:thin:@//127.0.0.1/xe`.

Default: undefined

### WEBAFIS_MIGRATION_WEB_AFIS_DATASOURCE_USERNAME

The username of the WebAFIS database user which has access to the required objects.

Default: undefined

### WEBAFIS_MIGRATION_WEB_AFIS_DATASOURCE_PASSWORD

The password that relates to WEBAFIS_MIGRATION_WEB_AFIS_DATASOURCE_USERNAME

Default: undefined

### WEBAFIS_MIGRATION_WEB_AFIS_DB_POOL_SIZE

The maximum pool size for database connections.
As a rule of thumb the maximum size should not be higher than: (core_count * 2) + spindle_count
Where core_count means physical cores whithout HyperThreading and spindle_count means all spindles combined in involved hard-drives.
E.g. if the database runs on a Core-i7-7700k with one hard-disk you should go with 9 or 10.

Default: 10

### WEBAFIS_MIGRATION_WEB_ABIS_JDBC_URL

Configure the complete JDBC URL of the WebABIS database

Examples:

- Oracle: 'jdbc:oracle:thin:@//127.0.0.1/xe'
- MySQL: 'jdbc:mysql://127.0.0.1:3306/webabis'
- PostgreSQL: 'jdbc:postgresql://127.0.0.1:5432/webabis?currentSchema=schema'
- H2: 'jdbc:h2:tcp://localhost:1521/webabis'

Default: undefined

### WEBAFIS_MIGRATION_WEB_ABIS_DATASOURCE_USERNAME

The username of the WebABIS database user which has access to the required objects.

Default: undefined

### WEBAFIS_MIGRATION_WEB_ABIS_DATASOURCE_PASSWORD

The password that relates to WEBAFIS_MIGRATION_WEB_ABIS_DATASOURCE_PASSWORD

Default: undefined

### WEBAFIS_MIGRATION_WEB_ABIS_DB_POOL_SIZE

The maximum pool size for database connections.
As a rule of thumb the maximum size should not be higher than: (core_count * 2) + spindle_count
Where core_count means physical cores whithout HyperThreading and spindle_count means all spindles combined in involved hard-drives.
E.g. if the database runs on a Core-i7-7700k with one hard-disk you should go with 9 or 10.

Default: 10

### WEBAFIS_MIGRATION_WEB_ABIS_DATASOURCE_DB_VARIANT

The variant of the WebABIS database: `oracle`, `mysql`, `postgresql`, `h2`, `h2-embedded`

Default: undefined

### WEBAFIS_MIGRATION_LOGGING_DATE_FORMAT

Defines the date/time format to be used in the log files.

Default:

    WEBAFIS_MIGRATION_LOGGING_DATE_FORMAT: >
      "yyyy-MM-dd'T'HH:mm:ss,SSSXXX", UTC

### DERMALOG_ABIS_VERSIONS_WEB_AFIS_MIGRATION

Defines the version of the package to be installed.

Default: undefined

## Dependencies

none

## Example Playbook

Include the role in your playbook(s).

    - hosts: web_afis_migration
      roles:
        - role: web_afis_migration

Configure the WebAFIS database connection details.

    WEBAFIS_MIGRATION_WEB_AFIS_JDBC_URL: 'jdbc:oracle:thin:@//localhost:1521/XE'
    WEBAFIS_MIGRATION_WEB_AFIS_DATASOURCE_USERNAME: 'DEMOGRAPHIC'
    WEBAFIS_MIGRATION_WEB_AFIS_DATASOURCE_PASSWORD: 'DEMOGRAPHIC'

Configure the WebABIS database connection details.

    WEBAFIS_MIGRATION_WEB_ABIS_JDBC_URL: 'jdbc:oracle:thin:@//localhost:1521/XE'
    WEBAFIS_MIGRATION_WEB_ABIS_DATASOURCE_USERNAME: 'webabis'
    WEBAFIS_MIGRATION_WEB_ABIS_DATASOURCE_PASSWORD: 'webabis'
    WEBAFIS_MIGRATION_WEB_ABIS_DATASOURCE_DB_VARIANT: 'oracle'

## License

proprietary
