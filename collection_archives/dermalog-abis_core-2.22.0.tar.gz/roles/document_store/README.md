# document_store

- [document_store](#document_store)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [DOCUMENT_STORE_JAVA_HOME](#document_store_java_home)
    - [DOCUMENT_STORE_SERVER_PORT](#document_store_server_port)
    - [DOCUMENT_STORE_CONTEXT_PATH](#document_store_context_path)
    - [DOCUMENT_STORE_CORS_ALLOWED_ORIGINS](#document_store_cors_allowed_origins)
    - [DOCUMENT_STORE_SERVICE_MAX_THREADS](#document_store_service_max_threads)
    - [DOCUMENT_STORE_DB_VARIANT](#document_store_db_variant)
    - [DOCUMENT_STORE_DATASOURCE_URL](#document_store_datasource_url)
    - [DOCUMENT_STORE_DB_USERNAME](#document_store_db_username)
    - [DOCUMENT_STORE_DB_PWD](#document_store_db_pwd)
    - [DOCUMENT_STORE_DB_POOL_SIZE](#document_store_db_pool_size)
    - [DOCUMENT_STORE_ID_GENERATION_DATABASE_IDENTIFIER](#document_store_id_generation_database_identifier)
    - [DOCUMENT_STORE_ID_GENERATION_GENERATION_SIZE](#document_store_id_generation_generation_size)
    - [DERMALOG_ABIS_VERSIONS_DOCUMENT_STORE](#dermalog_abis_versions_document_store)
    - [DOCUMENT_STORE_LOGGING_DATE_FORMAT](#document_store_logging_date_format)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs and configures the DocumentStore service.

## Requirements

none

## Role Variables

### DOCUMENT_STORE_JAVA_HOME

Defines the Java home directory to start the service with.

Default:

    DOCUMENT_STORE_JAVA_HOME: '/etc/alternatives/jre_11'

### DOCUMENT_STORE_SERVER_PORT

The http port providing REST endpoints and monitoring functionality.

Default:

    DOCUMENT_STORE_SERVER_PORT: 18000

### DOCUMENT_STORE_CONTEXT_PATH

The context path of the service.

Default:

    DOCUMENT_STORE_CONTEXT_PATH: '/v1'

### DOCUMENT_STORE_CORS_ALLOWED_ORIGINS

Defines the allowed origins for Cross-Origin Resource Sharing (CORS).

If not set or empty no cross origin is allowed, multiple origins are possible - separate them with a comma.

Default:

    DOCUMENT_STORE_CORS_ALLOWED_ORIGINS: ''

### DOCUMENT_STORE_SERVICE_MAX_THREADS

Defines the number of requests that can be processed in parallel.

When there are more incoming requests then the system will stall processing of the additional requests until threads are free for new work.

Default:

    DOCUMENT_STORE_SERVICE_MAX_THREADS: 200

### DOCUMENT_STORE_DB_VARIANT

The variant of the DocumentStore database: `oracle`, `mysql`, `postgresql`.

Default: undefined

### DOCUMENT_STORE_DATASOURCE_URL

The complete JDBC URL of the DocumentStore database.

Examples:

- Oracle: `jdbc:oracle:thin:@//127.0.0.1/xe`
- MySQL: `jdbc:mysql://127.0.0.1:3306/documentstore`
- PostgreSQL: `jdbc:postgresql://127.0.0.1:5432/documentstore?currentSchema=schema`

Default: undefined

### DOCUMENT_STORE_DB_USERNAME

The username to access the DocumentStore database.

Default: undefined

### DOCUMENT_STORE_DB_PWD

The password to access the DocumentStore database.

Default: undefined

### DOCUMENT_STORE_DB_POOL_SIZE

The maximum pool size for database connections.

Default:

    DOCUMENT_STORE_DB_POOL_SIZE: 10

### DERMALOG_ABIS_VERSIONS_DOCUMENT_STORE

The version of the package to be installed.

Default: undefined

### DOCUMENT_STORE_ID_GENERATION_DATABASE_IDENTIFIER

The value consists of two parts, the index of the database and the total number of involved databases, i.e.

&lt;Index&gt; / &lt;Total&gt;

If the DocumentStore is a single instance which runs against a single database the value shall be
the default value, '1/1'.
If you intend to scale the DocumentStore horizontally, running multiple instances of the DocumentStore but
still using a single database then the default value is also the way to go.
If you intend to run multiple instances of the DocumentStore, each with its own database and those
databases are synchronized, for example by GoldenGate, the default value will NOT do.
Lets say you have three DocumentStores each with its own database, then the value shall be '1/3', '2/3' and
'3/3' respectively.

Default:
DOCUMENT_STORE_ID_GENERATION_DATABASE_IDENTIFIER: '1/1'

### DOCUMENT_STORE_ID_GENERATION_GENERATION_SIZE

The amount of IDs which shall be reserved each time a new ID chunk is requested.

Default:

    DOCUMENT_STORE_ID_GENERATION_GENERATION_SIZE: 10000

### DOCUMENT_STORE_LOGGING_DATE_FORMAT

Defines the date/time format to be used for log entries.
By default there will be logged in UTC time.

Default:

    DOCUMENT_STORE_LOGGING_DATE_FORMAT: >
      "yyyy-MM-dd'T'HH:mm:ss,SSSXXX", UTC

## Dependencies

none

## Example Playbook

Include the role in your playbook(s).

    - hosts: abismain
      roles:
        - role: document_store

Configure the database connection details.

    DOCUMENT_STORE_DB_VARIANT: 'mysql'
    DOCUMENT_STORE_DATASOURCE_URL: 'jdbc:mysql://127.0.0.1:3306/DOCUMENTSTORE?useSSL=false'
    DOCUMENT_STORE_DB_USERNAME: 'documentstore'
    DOCUMENT_STORE_DB_PWD: 'documentstore'

## License

proprietary
