# abis_template_migrator

- [abis_template_migrator](#abis_template_migrator)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [DERMALOG_ABIS_VERSIONS_ABIS_TEMPLATE_MIGRATOR](#dermalog_abis_versions_abis_template_migrator)
    - [ABIS_TEMPLATE_MIGRATOR_JAVA_HOME](#abis_template_migrator_java_home)
    - [ABIS_TEMPLATE_MIGRATOR_CONTINUOUS_MIGRATION](#abis_template_migrator_continuous_migration)
    - [ABIS_TEMPLATE_MIGRATOR_CONTINUOUS_MIGRATION_CRON_SCHEDULE](#abis_template_migrator_continuous_migration_cron_schedule)
    - [ABIS_TEMPLATE_MIGRATOR_RECODE_FACE](#abis_template_migrator_recode_face)
    - [ABIS_TEMPLATE_MIGRATOR_MIGRATION_THREADS](#abis_template_migrator_migration_threads)
    - [ABIS_TEMPLATE_MIGRATOR_MIGRATION_THREADS_EXCEPTIONS](#abis_template_migrator_migration_threads_exceptions)
    - [ABIS_TEMPLATE_MIGRATOR_STATUS_LOG_RATE](#abis_template_migrator_status_log_rate)
    - [ABIS_TEMPLATE_MIGRATOR_ZMQ_FAST_MESSAGE_RECEIVE_TIMEOUT](#abis_template_migrator_zmq_fast_message_receive_timeout)
    - [ABIS_TEMPLATE_MIGRATOR_ZMQ_SLOW_MESSAGE_RECEIVE_TIMEOUT](#abis_template_migrator_zmq_slow_message_receive_timeout)
    - [ABIS_TEMPLATE_MIGRATOR_SOURCE_BIOMETRIC_STORE_URL](#abis_template_migrator_source_biometric_store_url)
    - [ABIS_TEMPLATE_MIGRATOR_SOURCE_BIOMETRIC_STORE_ENCRYPTION_CLIENT_KEYS_PATH](#abis_template_migrator_source_biometric_store_encryption_client_keys_path)
    - [ABIS_TEMPLATE_MIGRATOR_SOURCE_BIOMETRIC_STORE_ENCRYPTION_SERVER_KEYS_PATH](#abis_template_migrator_source_biometric_store_encryption_server_keys_path)
    - [ABIS_TEMPLATE_MIGRATOR_TARGET_BIOMETRIC_STORE_URL](#abis_template_migrator_target_biometric_store_url)
    - [ABIS_TEMPLATE_MIGRATOR_TARGET_BIOMETRIC_STORE_ENCRYPTION_CLIENT_KEYS_PATH](#abis_template_migrator_target_biometric_store_encryption_client_keys_path)
    - [ABIS_TEMPLATE_MIGRATOR_TARGET_BIOMETRIC_STORE_ENCRYPTION_SERVER_KEYS_PATH](#abis_template_migrator_target_biometric_store_encryption_server_keys_path)
    - [ABIS_TEMPLATE_MIGRATOR_TARGET_ABIS_WEBSERVICE_URL](#abis_template_migrator_target_abis_webservice_url)
    - [ABIS_TEMPLATE_MIGRATOR_BIOMETRIC_API_URL](#abis_template_migrator_biometric_api_url)
    - [ABIS_TEMPLATE_MIGRATOR_LOGGING_DATE_FORMAT](#abis_template_migrator_logging_date_format)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs and configures the ABIS Sync service.

## Requirements

none

## Role Variables

### DERMALOG_ABIS_VERSIONS_ABIS_TEMPLATE_MIGRATOR

The package version of the ABIS Template Migrator.

Default: undefined

### ABIS_TEMPLATE_MIGRATOR_JAVA_HOME

Defines the JAVA_HOME to be used for starting the service.

Default:

`ABIS_TEMPLATE_MIGRATOR_JAVA_HOME: '/etc/alternatives/jre_11'`

### ABIS_TEMPLATE_MIGRATOR_CONTINUOUS_MIGRATION

Whether the migration shall restart after a successful run or not.
If `true` the slave is always kept up to date.

Default:

    ABIS_TEMPLATE_MIGRATOR_CONTINUOUS_MIGRATION: false

### ABIS_TEMPLATE_MIGRATOR_CONTINUOUS_MIGRATION_CRON_SCHEDULE

If continuous migration is enabled this 6-field cron expression (second, minute, hour, day of month, month, day of week) defines the interval / start-times of the migrations.

If a migration is still running no additional migration will be started.

Default:

    ABIS_TEMPLATE_MIGRATOR_CONTINUOUS_MIGRATION_CRON_SCHEDULE: '0 0/20 * * * *'

### ABIS_TEMPLATE_MIGRATOR_RECODE_FACE

Whether the face biometric shall be recoded or not.

Default:

    ABIS_TEMPLATE_MIGRATOR_RECODE_FACE: false

### ABIS_TEMPLATE_MIGRATOR_MIGRATION_THREADS

The number of threads the migration runs with.

Default:

    ABIS_TEMPLATE_MIGRATOR_MIGRATION_THREADS: 32

### ABIS_TEMPLATE_MIGRATOR_MIGRATION_THREADS_EXCEPTIONS

Define additional times when the default number of threads will not apply. E.g. on night time additional threads are possible.
The system clock applies for the defined time ranges.

Define the exceptions as key-value pairs, where the key is the time range and the value is the number of migration threads,
like this: ``{'21:00-05:00': 64, '11:30-14:00': 16}``

Default: undefined

### ABIS_TEMPLATE_MIGRATOR_STATUS_LOG_RATE

The interval in seconds the migration status is logged to the status log.

Default:

    ABIS_TEMPLATE_MIGRATOR_STATUS_LOG_RATE: 120

### ABIS_TEMPLATE_MIGRATOR_ZMQ_FAST_MESSAGE_RECEIVE_TIMEOUT

A timeout in seconds for all requests that are supposed to be answered quickly.

Default:

    ABIS_TEMPLATE_MIGRATOR_ZMQ_FAST_MESSAGE_RECEIVE_TIMEOUT: 10

### ABIS_TEMPLATE_MIGRATOR_ZMQ_SLOW_MESSAGE_RECEIVE_TIMEOUT

A timeout in seconds for all requests that are supposed to be answered slowly.

Default:

    ABIS_TEMPLATE_MIGRATOR_ZMQ_SLOW_MESSAGE_RECEIVE_TIMEOUT: 60

### ABIS_TEMPLATE_MIGRATOR_SOURCE_BIOMETRIC_STORE_URL

The TCP connection URL for the BiometricStore that shall be migrated.

Default:

    ABIS_TEMPLATE_MIGRATOR_SOURCE_BIOMETRIC_STORE_URL: 'tcp://127.0.0.1:15000'

### ABIS_TEMPLATE_MIGRATOR_SOURCE_BIOMETRIC_STORE_ENCRYPTION_CLIENT_KEYS_PATH

The path to the folder containing the client key pair files - ``public.key``, ``private.key`` - used for encrypted communication with ``ABIS_TEMPLATE_MIGRATOR_SOURCE_BIOMETRIC_STORE_URL``.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_TEMPLATE_MIGRATOR_SOURCE_BIOMETRIC_STORE_ENCRYPTION_SERVER_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_TEMPLATE_MIGRATOR_SOURCE_BIOMETRIC_STORE_ENCRYPTION_SERVER_KEYS_PATH

The path to the folder containing the public server key file - ``public.key`` - used for encrypted communication with ``ABIS_TEMPLATE_MIGRATOR_SOURCE_BIOMETRIC_STORE_URL``.

The public key corresponds to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_TEMPLATE_MIGRATOR_SOURCE_BIOMETRIC_STORE_ENCRYPTION_CLIENT_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_TEMPLATE_MIGRATOR_TARGET_BIOMETRIC_STORE_URL

The TCP connection URL for the new BiometricStore containing the migrated records.

Default:

    ABIS_TEMPLATE_MIGRATOR_TARGET_BIOMETRIC_STORE_URL: 'tcp://127.0.0.1:15099'

### ABIS_TEMPLATE_MIGRATOR_TARGET_BIOMETRIC_STORE_ENCRYPTION_CLIENT_KEYS_PATH

The path to the folder containing the client key pair files - ``public.key``, ``private.key`` - used for encrypted communication with ``ABIS_TEMPLATE_MIGRATOR_TARGET_BIOMETRIC_STORE_URL``.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_TEMPLATE_MIGRATOR_TARGET_BIOMETRIC_STORE_ENCRYPTION_SERVER_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_TEMPLATE_MIGRATOR_TARGET_BIOMETRIC_STORE_ENCRYPTION_SERVER_KEYS_PATH

The path to the folder containing the public server key file - ``public.key`` - used for encrypted communication with ``ABIS_TEMPLATE_MIGRATOR_TARGET_BIOMETRIC_STORE_URL``.

The public key corresponds to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_TEMPLATE_MIGRATOR_TARGET_BIOMETRIC_STORE_ENCRYPTION_CLIENT_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_TEMPLATE_MIGRATOR_TARGET_ABIS_WEBSERVICE_URL

In case the biometric recoding is activated this ABISWebservice is used for encoding into the new template versions.

Default:

    ABIS_TEMPLATE_MIGRATOR_TARGET_ABIS_WEBSERVICE_URL: 'http://127.0.0.1:8099/v1'

### ABIS_TEMPLATE_MIGRATOR_BIOMETRIC_API_URL

In case the biometric recoding is activated this is the REST service URL for getting the biometric data for the migrated records.

Default:

    ABIS_TEMPLATE_MIGRATOR_BIOMETRIC_API_URL: 'http://127.0.0.1:10099/v1'

### ABIS_TEMPLATE_MIGRATOR_LOGGING_DATE_FORMAT

Defines the date/time format to be used for log entries.
By default there will be logged in UTC time.

Default:

    ABIS_TEMPLATE_MIGRATOR_LOGGING_DATE_FORMAT: >
      "yyyy-MM-dd'T'HH:mm:ss,SSSXXX", UTC

## Dependencies

none

## Example Playbook

Include the role in your playbook(s).

    - hosts: abismain
      roles:
        - role: abis_template_migrator

## License

proprietary
