# abis_deduplication

- [abis_deduplication](#abis_deduplication)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [ABIS_DEDUPLICATION_JAVA_HOME](#abis_deduplication_java_home)
    - [ABIS_DEDUPLICATION_CONTINUOUS_DEDUPLICATION](#abis_deduplication_continuous_deduplication)
    - [ABIS_DEDUPLICATION_CONTINUOUS_DEDUPLICATION_CRON_SCHEDULE](#abis_deduplication_continuous_deduplication_cron_schedule)
    - [ABIS_DEDUPLICATION_THREADS](#abis_deduplication_threads)
    - [ABIS_DEDUPLICATION_THREADS_EXCEPTIONS](#abis_deduplication_threads_exceptions)
    - [ABIS_DEDUPLICATION_STATUS_LOG_RATE](#abis_deduplication_status_log_rate)
    - [ABIS_DEDUPLICATION_ABIS_MATCHER_ADDRESS_URL](#abis_deduplication_abis_matcher_address_url)
    - [ABIS_DEDUPLICATION_ABIS_MATCHER_ENCRYPTION_CLIENT_KEYS_PATH](#abis_deduplication_abis_matcher_encryption_client_keys_path)
    - [ABIS_DEDUPLICATION_ABIS_MATCHER_ENCRYPTION_SERVER_KEYS_PATH](#abis_deduplication_abis_matcher_encryption_server_keys_path)
    - [ABIS_DEDUPLICATION_ABIS_MATCHER_SEARCH_CONFIG](#abis_deduplication_abis_matcher_search_config)
    - [ABIS_DEDUPLICATION_ABIS_MATCHER_SEARCH_THRESHOLD](#abis_deduplication_abis_matcher_search_threshold)
    - [ABIS_DEDUPLICATION_ABIS_MATCHER_VERIFICATION_CONFIG](#abis_deduplication_abis_matcher_verification_config)
    - [ABIS_DEDUPLICATION_ZMQ_RECEIVE_DEFAULT_TIMEOUT](#abis_deduplication_zmq_receive_default_timeout)
    - [ABIS_DEDUPLICATION_ZMQ_RECEIVE_EXTENDED_TIMEOUT](#abis_deduplication_zmq_receive_extended_timeout)
    - [ABIS_DEDUPLICATION_BIOMETRIC_STORE_URL](#abis_deduplication_biometric_store_url)
    - [ABIS_DEDUPLICATION_BIOMETRIC_STORE_ENCRYPTION_CLIENT_KEYS_PATH](#abis_deduplication_biometric_store_encryption_client_keys_path)
    - [ABIS_DEDUPLICATION_BIOMETRIC_STORE_ENCRYPTION_SERVER_KEYS_PATH](#abis_deduplication_biometric_store_encryption_server_keys_path)
    - [ABIS_DEDUPLICATION_DB_VARIANT](#abis_deduplication_db_variant)
    - [ABIS_DEDUPLICATION_DATASOURCE_URL](#abis_deduplication_datasource_url)
    - [ABIS_DEDUPLICATION_DB_USERNAME](#abis_deduplication_db_username)
    - [ABIS_DEDUPLICATION_DB_PWD](#abis_deduplication_db_pwd)
    - [ABIS_DEDUPLICATION_DB_POOL_SIZE](#abis_deduplication_db_pool_size)
    - [ABIS_DEDUPLICATION_LOGGING_DATE_FORMAT](#abis_deduplication_logging_date_format)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs and configures the ABISDeduplication service.

## Requirements

none

## Role Variables

### ABIS_DEDUPLICATION_JAVA_HOME

Defines the Java home directory to start the service with.

Default:

    ABIS_DEDUPLICATION_JAVA_HOME: '/etc/alternatives/jre_11'

### ABIS_DEDUPLICATION_CONTINUOUS_DEDUPLICATION

Whether the deduplication shall restart after a successful run or not.
If `true` the slave is always kept up to date.

Default:

    ABIS_DEDUPLICATION_CONTINUOUS_DEDUPLICATION: false

### ABIS_DEDUPLICATION_CONTINUOUS_DEDUPLICATION_CRON_SCHEDULE

If continuous deduplication is enabled this 6-field cron expression (second, minute, hour, day of month, month, day of week) defines the interval / start-times of the deduplications.

If a deduplication is still running no additional deduplication will be started.

Default:

    ABIS_DEDUPLICATION_CONTINUOUS_DEDUPLICATION_CRON_SCHEDULE: '0 0/20 * * * *'

### ABIS_DEDUPLICATION_THREADS

The number of threads the deduplication runs with.

Default:

    ABIS_DEDUPLICATION_THREADS: 32

### ABIS_DEDUPLICATION_THREADS_EXCEPTIONS

Define additional times when the default number of threads will not apply. E.g. on night time additional threads are possible.
The system clock applies for the defined time ranges.

Define the exceptions as key-value pairs, where the key is the time range and the value is the number of deduplication threads,
like this: ``{'21:00-05:00': 64, '11:30-14:00': 16}``

Default: undefined

### ABIS_DEDUPLICATION_STATUS_LOG_RATE

The interval in seconds the deduplication status is logged to the status log.

Default:

    ABIS_DEDUPLICATION_STATUS_LOG_RATE: 120

### ABIS_DEDUPLICATION_ABIS_MATCHER_ADDRESS_URL

The TCP connection URL of the ABIS Matching Dispatcher of the ABIS Backend.

Default:

    ABIS_DEDUPLICATION_ABIS_MATCHER_ADDRESS_URL: 'tcp://127.0.0.1:5555'

### ABIS_DEDUPLICATION_ABIS_MATCHER_ENCRYPTION_CLIENT_KEYS_PATH

The path to the folder containing the client key pair files - ``public.key``, ``private.key`` - used for encrypted communication with ``ABIS_DEDUPLICATION_ABIS_MATCHER_ADDRESS_URL``.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_DEDUPLICATION_ABIS_MATCHER_ENCRYPTION_SERVER_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_DEDUPLICATION_ABIS_MATCHER_ENCRYPTION_SERVER_KEYS_PATH

The path to the folder containing the public server key file - ``public.key`` - used for encrypted communication with ``ABIS_DEDUPLICATION_ABIS_MATCHER_ADDRESS_URL``.

The public key corresponds to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_DEDUPLICATION_ABIS_MATCHER_ENCRYPTION_CLIENT_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_DEDUPLICATION_ABIS_MATCHER_SEARCH_CONFIG

The ABIS Matching configuration used for searching possible duplicates.

Default: undefined

### ABIS_DEDUPLICATION_ABIS_MATCHER_SEARCH_THRESHOLD

The ABIS Matching search threshold.

Default:

    ABIS_DEDUPLICATION_ABIS_MATCHER_SEARCH_THRESHOLD: 50.0

### ABIS_DEDUPLICATION_ABIS_MATCHER_VERIFICATION_CONFIG

The ABIS Matching configuration used for resolving the modality scores of possible duplicates.

Default: undefined

### ABIS_DEDUPLICATION_ZMQ_RECEIVE_DEFAULT_TIMEOUT

A timeout in seconds for all ZeroMQ requests that are supposed to be answered quickly.

Default:

    ABIS_DEDUPLICATION_ZMQ_RECEIVE_DEFAULT_TIMEOUT: 10

### ABIS_DEDUPLICATION_ZMQ_RECEIVE_EXTENDED_TIMEOUT

A timeout in seconds for all ZeroMQ requests that are supposed to be answered slowly.

Default:

    ABIS_DEDUPLICATION_ZMQ_RECEIVE_EXTENDED_TIMEOUT: 120

### ABIS_DEDUPLICATION_BIOMETRIC_STORE_URL

The TCP connection URL of the BiometricStore of the ABIS Backend.

Default:

    ABIS_DEDUPLICATION_BIOMETRIC_STORE_URL: 'tcp://127.0.0.1:15000'

### ABIS_DEDUPLICATION_BIOMETRIC_STORE_ENCRYPTION_CLIENT_KEYS_PATH

The path to the folder containing the client key pair files - ``public.key``, ``private.key`` - used for encrypted communication with ``ABIS_DEDUPLICATION_BIOMETRIC_STORE_URL``.

The keys correspond to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_DEDUPLICATION_BIOMETRIC_STORE_ENCRYPTION_SERVER_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_DEDUPLICATION_BIOMETRIC_STORE_ENCRYPTION_SERVER_KEYS_PATH

The path to the folder containing the public server key file - ``public.key`` - used for encrypted communication with ``ABIS_DEDUPLICATION_BIOMETRIC_STORE_URL``.

The public key corresponds to the combined Curve25519, Salsa20 and Poly1305 encryption, which is described at https://nacl.cr.yp.to/valid.html.

If set the ``ABIS_DEDUPLICATION_BIOMETRIC_STORE_ENCRYPTION_CLIENT_KEYS_PATH`` has to be set as well.

Default: undefined

### ABIS_DEDUPLICATION_DB_VARIANT

The variant of the ABIS Deduplication database: `oracle`, `mysql`, `postgresql`.

Default: undefined

### ABIS_DEDUPLICATION_DATASOURCE_URL

The complete JDBC URL of the ABIS Deduplication database.

Examples:

- Oracle: `jdbc:oracle:thin:@//127.0.0.1/xe`
- MySQL: `jdbc:mysql://127.0.0.1:3306/abisdeduplication`
- PostgreSQL: `jdbc:postgresql://127.0.0.1:5432/abisdeduplication?currentSchema=schema`

Default: undefined

### ABIS_DEDUPLICATION_DB_USERNAME

The username to access the ABIS Deduplication database.

Default: undefined

### ABIS_DEDUPLICATION_DB_PWD

The password to access the ABIS Deduplication database.

Default: undefined

### ABIS_DEDUPLICATION_DB_POOL_SIZE

The maximum pool size for database connections.

Default:

    ABIS_DEDUPLICATION_DB_POOL_SIZE: 10

### ABIS_DEDUPLICATION_LOGGING_DATE_FORMAT

Defines the date/time format to be used for log entries.
By default there will be logged in UTC time.

Default:

    ABIS_DEDUPLICATION_LOGGING_DATE_FORMAT: >
      "yyyy-MM-dd'T'HH:mm:ss,SSSXXX", UTC

## Dependencies

- role: abis_common

## Example Playbook

Include the role in your playbook(s).

    - hosts: abismain
      roles:
        - role: abis_deduplication

Configure the ABIS Matching and database connection details.

    ABIS_DEDUPLICATION_ABIS_MATCHER_SEARCH_CONFIG: 'civil_demo'
    ABIS_DEDUPLICATION_ABIS_MATCHER_VERIFICATION_CONFIG: 'civil_demo'
    ABIS_DEDUPLICATION_DB_VARIANT: 'mysql'
    ABIS_DEDUPLICATION_DATASOURCE_URL: 'jdbc:mysql://127.0.0.1:3306/ABISDEDUPLICATION?useSSL=false'
    ABIS_DEDUPLICATION_DB_USERNAME: 'abisdeduplication'
    ABIS_DEDUPLICATION_DB_PWD: 'abisdeduplication'

## License

proprietary
