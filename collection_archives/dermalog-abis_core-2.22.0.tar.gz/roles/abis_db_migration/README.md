# abis_db_migration

- [abis_db_migration](#abis_db_migration)
  - [Requirements](#requirements)
  - [Role Variables](#role-variables)
    - [ABIS_DB_MIGRATION_INSTALL_PACKAGES](#abis_db_migration_install_packages)
    - [ABIS_DB_MIGRATION_EXEC_MIGRATIONS](#abis_db_migration_exec_migrations)
    - [DERMALOG_ABIS_VERSIONS_DB_MIGRATION](#dermalog_abis_versions_db_migration)
  - [Dependencies](#dependencies)
  - [Example Playbook](#example-playbook)
  - [License](#license)

This role installs packages for database migration scripts and prepares database schemas.

## Requirements

none

## Role Variables

### ABIS_DB_MIGRATION_INSTALL_PACKAGES

Installs the migration tool for the defined services and databases.

For each package there has to be defined a hash entry with attributes:

- `service_type`: Possible values `'biometric-store'`, `'web-abis'`, `'abis-deduplication'`, `document-store`
- `db_variant`: Possible values `'oracle'`, `'postgresql'`, `'mysql'`, `'h2'`
  - `'abis-deduplication'` only supports: `'oracle'`, `'mysql'`

Example for installing the package dermalog-biometric-store-migration-mysql:

    ABIS_DB_MIGRATION_INSTALL_PACKAGES:
      - service_type: 'biometric-store'
        db_variant: 'mysql'

Default:

    ABIS_DB_MIGRATION_INSTALL_PACKAGES: "{{ ABIS_DB_MIGRATION_EXEC_MIGRATIONS }}"

### ABIS_DB_MIGRATION_EXEC_MIGRATIONS

Executes the migration tools for the configured services and databases.

It is expected that as a precondition all required users and databases are already prepared.

For each migration execution there has to be defined a hash entry with these attributes:

- `service_type`: Possible values `'biometric-store'`, `'web-abis'`, `'abis-deduplication'`, `document-store`
- `db_variant`: Possible values `'oracle'`, `'postgresql'`, `'mysql'`, `'h2'`
  - `'abis-deduplication'` and `document-store` only support: `'oracle'`, `'mysql'`
- `db_jdbc_url`: The JDBC URL of the database instance
- `db_system_user`: Database user with proper permissions so that database structures can be created
- `db_system_pwd`: The password of the administrative database user
- `db_schema`: The target schema/user in the database that is to be created (applies to `oracle` and `h2` only)
- `tablespace_tables`: The tablespace to be used for table objects (applies to `oracle` only)
- `tablespace_indices`: The tablespace to be used for index objects (applies to `oracle` only)
- `tablespace_lob`: The tablespace to be used for lob objects (applies to `oracle` only)

Example for exuting the migration tool for the BiometricStore against an Oracle instance, for the WebABIS service against a PostgreSQL instance and for ABIS Deduplication against an MariaDB/MySQL instance:

    ABIS_DB_MIGRATION_EXEC_MIGRATIONS:
      - service_type: 'biometric-store'
        db_variant: 'oracle'
        db_jdbc_url: 'jdbc:oracle:thin:@//dbhost:1521:abis'
        db_system_user: 'sys'
        db_system_pwd: 'oracle'
        db_schema: 'BIOSTORE'
        tablespace_tables: 'ts_tabs'
        tablespace_indices: 'ts_idx'
        tablespace_lob: 'ts_lob'
      - service_type: 'web-abis'
        db_variant: 'postgresql'
        db_jdbc_url: 'jdbc:postgresql://127.0.0.1:5432/webabis?currentSchema=schema'
        db_system_user: 'root'
        db_system_pwd: 'root'
      - service_type: 'abis-deduplication'
        db_variant: 'mysql'
        db_jdbc_url: 'jdbc:mysql://127.0.0.1:3306/abisdeduplication'
        db_system_user: 'root'
        db_system_pwd: 'root'

Default:

    ABIS_DB_MIGRATION_EXEC_MIGRATIONS: []

### DERMALOG_ABIS_VERSIONS_DB_MIGRATION

Defines the version of the migration package(s) to be installed.

Default: undefined

## Dependencies

none

## Example Playbook

Include the role in your playbook(s).

    - hosts: abismain
      roles:
        - role: abis_db_migration

This example would just install the packages with the migration scripts.

    DERMALOG_ABIS_VERSIONS_DB_MIGRATION: '1.0.0'
    ABIS_DB_MIGRATION_INSTALL_PACKAGES:
      - service_type: 'biometric-store'
        db_variant: 'mysql'
      - service_type: 'web-abis'
        db_variant: 'mysql'
      - service_type: 'abis-deduplication'
        db_variant: 'mysql'

This example would install the required packages with the migration scripts and execute them.

    DERMALOG_ABIS_VERSIONS_DB_MIGRATION: '1.0.0'
    ABIS_DB_MIGRATION_EXEC_MIGRATIONS:
      - service_type: 'biometric-store'
        db_variant: 'mysql'
        db_jdbc_url: 'jdbc:mysql://127.0.0.1:3306/BIOMETRICSTORE?useSSL=false'
        db_system_user: 'root'
        db_system_pwd: 'root'
      - service_type: 'web-abis'
        db_variant: 'mysql'
        db_jdbc_url: 'jdbc:mysql://127.0.0.1:3306/WEBABIS?useSSL=false'
        db_system_user: 'root'
        db_system_pwd: 'root'
      - service_type: 'abis-deduplication'
        db_variant: 'mysql'
        db_jdbc_url: 'jdbc:mysql://127.0.0.1:3306/ABISDEDUPLICATION?useSSL=false'
        db_system_user: 'root'
        db_system_pwd: 'root'

## License

proprietary
