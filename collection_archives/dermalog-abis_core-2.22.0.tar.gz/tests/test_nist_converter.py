#!/usr/bin/env python3
import os

import pytest

test_host = os.environ.get('TEST_HOST')
testinfra_hosts = [F"paramiko://root:dermalog!@{test_host}:22"]


def test_packages(host):
    assert host.package('dermalog-nist-converter-webservice').is_installed


@pytest.mark.parametrize('configuration_file', [
    ('/etc/opt/dermalog/nist-converter-webservice/application.properties'),
    ('/etc/opt/dermalog/nist-converter-webservice/logback.xml'),
    ('/etc/sysconfig/dermalog-nist-converter-webservice.systemd'),
    ('/usr/lib/systemd/system/dermalog-nist-converter-webservice.service'),
])
def test_configuration_files(host, configuration_file):
    assert 0o644 == host.file(configuration_file).mode

    dirname = os.path.dirname(__file__)
    fixture_path = os.path.join(dirname, 'fixtures' + configuration_file)
    assert open(fixture_path).read() == host.file(configuration_file).content_string


def test_service(host):
    assert host.service('dermalog-nist-converter-webservice').is_enabled
    assert host.service('dermalog-nist-converter-webservice').is_running
