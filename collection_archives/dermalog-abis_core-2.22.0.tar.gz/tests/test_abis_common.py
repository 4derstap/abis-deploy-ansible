#!/usr/bin/env python3
import os

import pytest

test_host = os.environ.get('TEST_HOST')
testinfra_hosts = [F"paramiko://root:dermalog!@{test_host}:22"]


@pytest.mark.parametrize('package_name', [
    ('dermalog-abis-systemcheck'),
    ('dermalog-cfg'),
    ('dermalog-sosplugin'),
])
def test_packages(host, package_name):
    assert host.package(package_name).is_installed
