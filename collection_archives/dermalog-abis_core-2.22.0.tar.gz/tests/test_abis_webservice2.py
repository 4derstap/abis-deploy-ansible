#!/usr/bin/env python3
import os

import pytest

test_host = os.environ.get('TEST_HOST')
testinfra_hosts = [F"paramiko://root:dermalog!@{test_host}:22"]


@pytest.mark.parametrize('package_name', [
    ('dermalog-abis-webservice2'),
    ('dermalog-abisfaceplugin2'),
    ('dermalog-abisfingerplugin'),
    ('dermalog-abisirisplugin'),
    ('dermalog-abismatching'),
    ('dermalog-abismatching-config'),
    ('dermalog-abispalmplugin'),
    ('dermalog-imagecontainer'),
    ('dermalog-fingercode3'),
    ('dermalog-abisfusion'),
    ('dermalog-iriscode'),
    ('dermalog-palmcode'),
    ('dermalog-matchingresultaccessor'),
    ('dermalog-templateaccessor'),
    ('dermalog-nistqualitycheck'),
    ('dermalog-formatansinist_itl1'),
    ('dermalog-facesdk-backendproducts'),
])
def test_packages(host, package_name):
    assert host.package(package_name).is_installed


@pytest.mark.parametrize('configuration_file', [
#     ('/etc/opt/dermalog/abis-webservice2/application.properties'), # this file is currently not testable with reasonable effort
    ('/etc/opt/dermalog/abis-webservice2/logback.xml'),
    ('/usr/lib/systemd/system/dermalog-abis-webservice2.service'),
    ('/etc/sysconfig/dermalog-abis-webservice2.systemd'),
])
def test_configuration_files(host, configuration_file):
    assert 0o644 == host.file(configuration_file).mode

    dirname = os.path.dirname(__file__)
    fixture_path = os.path.join(dirname, 'fixtures' + configuration_file)
    assert open(fixture_path).read() == host.file(configuration_file).content_string


def test_service(host):
    assert host.service('dermalog-abis-webservice2').is_enabled
    assert host.service('dermalog-abis-webservice2').is_running
