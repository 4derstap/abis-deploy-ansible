#!/usr/bin/env python3
import os
import pytest

test_host = os.environ.get('TEST_HOST')
testinfra_hosts = [F"paramiko://root:dermalog!@{test_host}:22"]


@pytest.mark.parametrize('package_name', [
    ('dermalog-abis-deduplication-migration-mysql'),
    ('dermalog-biometric-store-migration-mysql'),
    ('dermalog-document-store-migration-mysql'),
    ('dermalog-web-abis-migration-mysql'),
])
def test_packages(host, package_name):
    assert host.package(package_name).is_installed
