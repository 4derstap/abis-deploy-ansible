#!/usr/bin/env python3
import os

import pytest

test_host = os.environ.get('TEST_HOST')
testinfra_hosts = [F"paramiko://root:dermalog!@{test_host}:22"]


@pytest.mark.parametrize('package_name', [
    ('dermalog-abismatching-dispatcher'),
    ('dermalog-abismatching-admin'),
])
def test_packages(host, package_name):
    assert host.package(package_name).is_installed


@pytest.mark.parametrize('configuration_file', [
    ('/etc/opt/dermalog/abismatching-dispatcher/dispatcher.conf'),
    ('/etc/opt/dermalog/abismatching-dispatcher/logging.properties'),
    ('/usr/lib/systemd/system/dermalog-abismatching-dispatcher.service'),
])
def test_configuration_files(host, configuration_file):
    assert 0o644 == host.file(configuration_file).mode

    dirname = os.path.dirname(__file__)
    fixture_path = os.path.join(dirname, 'fixtures' + configuration_file)
    hostname = host.facter('hostname')['hostname']
    fixture_content = open(fixture_path).read().replace('{{ ABIS_DISPATCHER_SYMBOLIC_NAME }}', F"{hostname}")
    assert fixture_content == host.file(configuration_file).content_string


def test_service(host):
    assert host.service('dermalog-abismatching-dispatcher').is_enabled
    assert host.service('dermalog-abismatching-dispatcher').is_running
