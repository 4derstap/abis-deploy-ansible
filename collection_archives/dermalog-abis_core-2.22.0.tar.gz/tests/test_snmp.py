#!/usr/bin/env python3
import os

import pytest

test_host = os.environ.get('TEST_HOST')
testinfra_hosts = [F"paramiko://root:dermalog!@{test_host}:22"]


def test_packages(host):
    assert host.package('net-snmp').is_installed
    assert host.package('net-snmp-libs').is_installed
    assert host.package('net-snmp-utils').is_installed


@pytest.mark.parametrize('configuration_file,file_mode', [
    ('/etc/snmp/snmp.conf', 0o644),
    ('/etc/snmp/snmpd.conf', 0o600),
    ('/etc/sysconfig/snmpd', 0o644),
])
def test_configuration_files(host, configuration_file, file_mode):
    assert file_mode == host.file(configuration_file).mode

    dirname = os.path.dirname(__file__)
    fixture_path = os.path.join(dirname, 'fixtures' + configuration_file)
    fqdn = host.facter('fqdn')['fqdn']
    fixture_content = open(fixture_path).read().replace('{{ FQDN }}', F"{fqdn}")
    assert fixture_content == host.file(configuration_file).content_string


def test_service(host):
    assert host.service('snmpd').is_enabled
    assert host.service('snmpd').is_running
