#!/usr/bin/env python3
import os

test_host = os.environ.get('TEST_HOST')
testinfra_hosts = [F"paramiko://root:dermalog!@{test_host}:22"]


def test_packages(host):
    assert host.package('CodeMeter').is_installed


def test_service(host):
    assert host.service('codemeter').is_enabled
    assert host.service('codemeter').is_running
