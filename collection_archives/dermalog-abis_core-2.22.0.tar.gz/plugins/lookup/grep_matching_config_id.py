from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = """
    name: grep_matching_config_id
    author: DERMALOG Identification Systems GmbH <info@dermalog.com>
    version_added: 1.5.0
    short_description: Greps the matching config ID out of a matching configuration file.
    description:
        - each matching configuration file starts with the name and its ID, e.g.: Name=civil_demo;ID=1159436283
        - this plugin greps the ID out of the given configuration file
    options:
        _terms:
            description: the path of the matching configuration file
            required: True
"""

EXAMPLES = """
    - debug: msg="{{ lookup('dermalog.abis_core.grep_matching_config_id', '/root/civil_demo.abiscfg') }}" # will be looked in absolute dir
    - debug: msg="{{ lookup('dermalog.abis_core.grep_matching_config_id', 'face_no_normalization.abiscfg') }}" # will be looked in files/ dir relative to play or in role
"""

RETURN = """
    _raw:
        description:
            - the matching configuration ID of the given file
        type: str
"""

import re

from ansible.errors import AnsibleError
from ansible.plugins.lookup import LookupBase
from ansible.utils.display import Display

display = Display()

class LookupModule(LookupBase):

    def run(self, terms, variables=None, **kwargs):

        ret = []
        for term in terms:
            display.debug("File lookup term: %s" % term)

            lookupfile = self.find_file_in_search_path(variables, 'files', term)
            display.vvvv(u"File lookup using %s as file" % lookupfile)

            if lookupfile:
                with open(lookupfile, mode='rb') as file:
                    # read the header information from the configuration file
                    fileContent = file.read()
                    nullIndex = fileContent.index(b'\x00')
                    configHeader = fileContent[0:nullIndex].decode('utf-8')

                    # grep the ID from the ID snippet
                    configId = re.search('[iI][dD]=(\d+)', configHeader).group(1)
                    ret.append(configId)
            else:
                raise AnsibleError("Could not locate file in lookup: %s" % term)

        return ret
