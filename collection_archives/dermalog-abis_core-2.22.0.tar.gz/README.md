# Ansible Collection - dermalog.abis

This collection contains roles and playbooks for installing and administering nodes with ABIS Backend services.

## Usage

Use the offered playbook *abis-playbook.yml* as is.
If you take this route then follow the explanations below.

Or include the roles in your own playbooks.
Please check the documentation of the roles of how to utilize them.

For any stuff that goes beyond this documentation you may want to learn from the official Ansible docs.

### Preconditions

* Prepare an inventory with groups matching the defined group names in the playbook:
  * *abismain* - main ABIS Backend services, includes roles biometric_store, abis_sync, abis_webservice2, abis_dispatcher
  * *satellites* - includes abis_satellite
  * *coders* - includes abis_webservice2
  * *nist_converter* - includes nist_converter
  * *web_abis* - includes web_abis
  * *web_abis_nist_extension* - includes web_abis_nist_extension
  * *web_abis_biometric_sample_provider* - includes web_abis_biometric_sample_provider
  * *abis_deduplication* - includes abis_deduplication
* Configure all parameters that are specific to the environment in *host_vars* and *group_vars* of the inventory.
* Ensure that you can access the inventory *abis* that ships with the ABIS Backend release.
* Optionally create a playbook and include the provided playbook *dermalog.abis_core.abis_install* (or run the provided playbook directly).
* For listing all defined host groups in the playbook you may issue this command: `ansible-playbook --list-hosts dermalog.abis_core.abis_install`.

**Hint**: It is highly recommended to make use of a source control system like [Git](https://git-scm.com/) in order to maintain configuration files.

**Please note**, that you can use the provided Ansible collection in custom playbooks by including the contained roles as required.

### Install the collection

Create a *requirements.yml*.

Get collection from git repository

```yaml
collections:
  - name: dermalog.abis_core
    source: ssh://gerrit.backend.dc.dermalog.hh:29418/abis_tools-ansible
    type: git
    version: 2.3.0
```

Get collection from Nexus repository

```yaml
---
collections:
- source: https://nexusrepo.dc.dermalog.com/repository/raw-releases/com/dermalog/ansible/dermalog-abis_core-2.3.0.tar.gz
  type: url
```

Or install the collection to a target directory as required in your environment: `ansible-galaxy collection install dermalog-abis_core-2.0.0.tar.gz -p ./collections`.

### Running the playbook

The roles contain tagged tasks so that they can be executed in a more controlled manor.

* *install* - Installs packages only
* *configure* - Configures all services without starting them
* *start* - Starts all configured services

It is recommended that you make use of the inventory containing the package versions of the ABIS Backend release.

#### Install and start the services in one shot

By default you would run all tasks with tags *install*, *configure* and *start* in one go.
For preparing all ABIS Backend services to the configured nodes you should run the playbook like this:

```sh
ansible-playbook -i path_to_abis_release/ansible/inventories/abis -i myinventory dermalog.abis_core.abis_install
```

#### Install the packages only

If you want to just install the packages of the ABIS Backend to the configured nodes you should run the playbook like this:

```sh
ansible-playbook -i path_to_abis_release/ansible/inventories/abis -i myinventory dermalog.abis_core.abis_install -t install
```

#### Configure the services only

If you want to just configure the services of the ABIS Backend to the specified nodes you should run the playbook like this:

```sh
ansible-playbook -i path_to_abis_release/ansible/inventories/abis -i myinventory dermalog.abis_core.abis_install -t configure
```

#### Start the services only

If you want to just start the configured services of the ABIS Backend to the configured nodes you should run the playbook like this:

```sh
ansible-playbook -i path_to_abis_release/ansible/inventories/abis -i myinventory dermalog.abis_core.abis_install -t start
```

### Clearing the ABIS Matching Satellite cache

There may be valid reasons to ensure a clean state of cache used by the ABIS Matching Satellite instances.
If you have configured the Satellite instances to have the cache in memory only then you are done by just restarting the services.

If using the memory mapped files you have to stop the services, remove the cache files and start the service instances again.
You can utilize the playbook *abis-delete-cache.yml* for automating the task of clearing the cache files.
Optionally you can stop and start the Satellite service instance right away.

It is assumed that your inventory includes a host group *satellites*.

```shell
# Example: Stops Satellite instances, clears the cache and starts the service instances.
ansible-playbook -i inventories/example dermalog.abis_core.abis_delete_cache -e stop_services=true -e start_services=true
```
