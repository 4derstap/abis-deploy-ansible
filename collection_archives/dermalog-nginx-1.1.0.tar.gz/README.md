# Ansible Collection - dermalog.nginx

This collection provides roles for installing and configuring nginx and creating ssl certificates.

## Usage

Create an inventory with hosts matching the group name `nginx_hosts` and run the included playbook *dermalog.nginx.nginx_install*.

```sh
ansible-playbook dermalog.nginx.nginx_install -i <path to your inventory>
```
