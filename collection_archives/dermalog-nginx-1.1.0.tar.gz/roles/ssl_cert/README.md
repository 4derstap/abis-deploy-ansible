# DERMALOG ssl_cert

The role creates SSL certificates

## Role Variables

### SSL_COMMON_NAME

## Example Playbook

## License

proprietary
