# DERMALOG NGINX

This role installs nginx and configures selfsigned certificates and some default proxy locations.

## Role Variables

### NGINX_SERVER

Defines the server name to be used in certificates.

Default: `"{{ ansible_facts['fqdn'] }}"`

### PROXY_LOCATIONS

Defines the locations to be proxied.

The locations are a list of hashes with keys

* LOCATION: The URL context path visible from outside.
* PROXY_SETTINGS: An array of proxy settings (added as given to the location settings).

Default: See defaults/main.yml

Example:

```yaml
PROXY_PASS_ORDS: http://127.0.0.1:8080/ords/
PROXY_PASS_IMG_SRC: http://127.0.0.1:8080/i/
PROXY_PASS_WEBABIS: http://127.0.0.1:10000/v1/
PROXY_PASS_ABIS: http://127.0.0.1:8080/abis/
PROXY_PASS_ADJUDICATION: http://127.0.0.1:7190/adjudication/

PROXY_LOCATIONS:
  - LOCATION: /ords/
    PROXY_PASS: "{{ PROXY_PASS_ORDS }}"
    PROXY_SETTINGS: "{{ PROXY_LOCATION_DEFAULT_SETTINGS + PROXY_LOCATION_HEADER_SETTINGS }}"
  - LOCATION: /i/
    PROXY_PASS: "{{ PROXY_PASS_IMG_SRC }}"
  - LOCATION: /v1/
    PROXY_PASS: "{{ PROXY_PASS_WEBABIS }}"
  - LOCATION: /abis/
    PROXY_PASS: "{{ PROXY_PASS_ABIS }}"
  - LOCATION: /adjudication/
    PROXY_PASS: "{{ PROXY_PASS_ADJUDICATION }}"
```

## Example Playbook

```yaml
- hosts: nginx_hosts
  roles:
    - role: nginx
```

## License

proprietary
