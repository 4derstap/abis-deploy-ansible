# Dermalog ABIS MariaDB

This role can be used to install and configure a MariaDB instance.

## Dependencies

* community.mysql

## Role Variables

### MARIADB_ROOT_PASSWORD

A root password for a MariaDB instance. If it's not defined an empty password will be used.

Default: none

### MARIADB_PACKAGES

A list of packages to be installed on the database hosts.

Default:

```yaml
MARIADB_PACKAGES:
- mariadb-server-10.3.28
- mariadb-server-utils-10.3.28
- python3-PyMySQL-0.10.1
```

### MARIADB_DBS

A list of databases that will be created during installation.

Default:

```yaml
MARIADB_DBS:
  - {database: 'BIOMETRICSTORE', user_name: 'BIOMETRICSTORE', host: '127.0.0.1', password: 'BIOMETRICSTORE'}
  - {database: 'WEBABIS', user_name: 'WEBABIS', host: '127.0.0.1', password: 'WEBABIS'}
```


## Example Playbook

Install MariaDB WEBABIS

```yaml
---
- hosts: mariadb_hosts
  become: true

  roles:
    - role: mariadb
      vars:
        MARIADB_ROOT_PASSWORD: 'root'
```

Install MariaDB only with the BiometricStore

```yaml
---
- hosts: mariadb_hosts
  become: true
  vars:
    MARIADB_ROOT_PASSWORD: 'root'
    MARIADB_DBS:
      - {database: 'BIOMETRICSTORE', user_name: 'BIOMETRICSTORE', host: '127.0.0.1', password: 'BIOMETRICSTORE'}

  roles:
    - role: mariadb
```

## License

proprietary
