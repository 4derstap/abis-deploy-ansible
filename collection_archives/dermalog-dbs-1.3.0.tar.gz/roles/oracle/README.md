# oracle

This role provides tasks for configuring tablespaces and users in Oracle database instance.

## Dependencies

The SQL commands are executed on a remote node. It is expected that:

* User `oracle` is avaible.
* And SQLPlus is in the path for the user `oracle`.

Usually this is already given, when you are using a Oracle database instance node.

## Role variables

### ORACLE_SID

Defines the Oracle SID that shall be used by SQLPlus when connecting to a pluggable database (pdb).

Example:

```yaml
ORACLE_PDB_SID: orclpdb1
```

### TABLESPACES

This defines a list of hashes where each hash entry contains the details of one tablespace.

Example:

```yaml
TABLESPACES:
  - TS_NAME: TS_ABIS
    TS_NEXT: '100M'
    TS_DATAFILE_PATH: ts_abis.dbf
    TS_SIZE: '100M'
    TS_MAX_SIZE: '32767M'
```

#### TS_NAME

Defines the name of the tablespace.

#### TS_NEXT

The size of the next increment for the tablespace when Oracle tries to allocate more disk space.

#### TS_DATAFILE_PATH

The name/path of the datafile. (optional)

#### TS_SIZE

The initial size of the tablespace. (optional)

#### TS_MAX_SIZE

The maximum size of the tablespace. (optional)s

### SCHEMAS

Defines the database schemas/users that shall be created in the database instance.

Example:

```yaml
SCHEMAS:
  - SCHEMA: DRM_BIOSTORE
    PASSWORD: drm_biostore
    DEFAULT_TABLESPACE: TS_ABIS
    TABLESPACES:
      - TS_ABIS
```

#### SCHEMA

Defines the name of the schema/user.

#### PASSWORD

The password of the database user.

**Please make use of ansible-vault in order to avoid clear text passwords in your inventory data.**

#### DEFAULT_TABLESPACE

The default tablespace of the user.

#### TABLESPACES

Defines a list of tablespace where disk quotas shall be granted to for the given user.

## Example playbook

```yaml
---
- hosts: oracle_databases
  roles:
    - oracle
```

## License

proprietary
