# Ansible Collection - dermalog.dbs

This collection contains roles and playbooks to install databases that can be used with ABIS
